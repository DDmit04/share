package handlers

import (
	"encoding/json"
	"net/http"
	"sort"
	"strings"
	"taskmon/internal/auth"
	"taskmon/internal/db"
	"taskmon/internal/models"
	"time"
)

type Hendlers struct {
	store *db.LocalStore
	auth  *auth.Auth
}

func New(_store *db.LocalStore, _auth *auth.Auth) *Hendlers {
	return &Hendlers{
		store: _store,
		auth:  _auth,
	}
}

func jsonOK(w http.ResponseWriter, v interface{}) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(v)
}
func jsonErr(w http.ResponseWriter, msg string, code int) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]string{"error": msg})
}

func isWorkday(t time.Time, holidays map[string]string) bool {
	wd := t.Weekday()
	if wd == time.Saturday || wd == time.Sunday {
		return false
	}
	if holidays != nil {
		if _, ok := holidays[t.Format("2006-01-02")]; ok {
			return false
		}
	}
	return true
}

// ===================== CALENDAR =====================

type DayInfo struct {
	Date        string `json:"date"`
	Label       string `json:"label"`
	IsToday     bool   `json:"is_today"`
	IsHoliday   bool   `json:"is_holiday"`
	HolidayName string `json:"holiday_name,omitempty"`
}

type StageBarDTO struct {
	StageID       string `json:"stage_id"`
	TaskID        string `json:"task_id"`
	Name          string `json:"name"`
	StageType     string `json:"stage_type"`
	Status        string `json:"status"`
	Color         string `json:"color"`
	StatusColor   string `json:"status_color"`
	StartDay      int    `json:"start_day"`
	EndDay        int    `json:"end_day"`
	StartDate     string `json:"start_date,omitempty"`
	EndDate       string `json:"end_date,omitempty"`
	AssignedLogin string `json:"assigned_login"`
	URLLink       string `json:"url_link"`
}

type TaskRowDTO struct {
	TaskID              string        `json:"task_id"`
	Name                string        `json:"name"`
	EconomicEffect      string        `json:"economic_effect"`
	Status              string        `json:"status"`
	Color               string        `json:"color"`
	HasDates            bool          `json:"has_dates"`
	HasUnassignedStages bool          `json:"has_unassigned_stages"`
	NoStages            bool          `json:"no_stages"` // task has zero stages
	Stages              []StageBarDTO `json:"stages"`
}

type OverloadDTO struct{ Start, End int }

func (o OverloadDTO) MarshalJSON() ([]byte, error) {
	return json.Marshal(map[string]int{"start": o.Start, "end": o.End})
}

type EmpRowDTO struct {
	Login     string        `json:"login"`
	FullName  string        `json:"full_name"`
	IsVirtual bool          `json:"is_virtual"`
	Tasks     []TaskRowDTO  `json:"tasks"`
	Overload  []OverloadDTO `json:"overload"`
}

type MonthStatDTO struct {
	Month string  `json:"month"`
	Hours float64 `json:"hours"`
	Class string  `json:"class"`
}

type EmpStatDTO struct {
	Login    string         `json:"login"`
	FullName string         `json:"full_name"`
	Months   []MonthStatDTO `json:"months"`
}

type CalendarDTO struct {
	Days      []DayInfo         `json:"days"`
	TodayIdx  int               `json:"today_idx"`
	Employees []EmpRowDTO       `json:"employees"`
	Stats     []EmpStatDTO      `json:"stats"`
	Holidays  map[string]string `json:"holidays"`
}

var monthNames = []string{"Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"}

func (h *Hendlers) Calendar(w http.ResponseWriter, r *http.Request) {
	user, _ := h.auth.GetCurrentUser(r)
	userDepartmentStructure, _ := h.store.GetUserDepartmentStructure(user)

	today := time.Now().Truncate(24 * time.Hour)
	calStart := time.Date(today.Year(), today.Month(), 1, 0, 0, 0, 0, today.Location())
	calEnd := time.Date(today.Year(), today.Month()+3, 0, 0, 0, 0, 0, today.Location())

	// Load holidays for all years in range
	holidays := map[string]string{}
	for yr := calStart.Year(); yr <= calEnd.Year(); yr++ {
		for k, v := range h.store.GetHolidays(yr) {
			holidays[k] = v
		}
	}

	var days []DayInfo
	var dayDates []time.Time
	todayIdx := 0
	for d := calStart; !d.After(calEnd); d = d.AddDate(0, 0, 1) {
		if !isWorkday(d, holidays) {
			continue
		}
		if d.Equal(today) {
			todayIdx = len(days)
		}
		hname := holidays[d.Format("2006-01-02")]
		days = append(days, DayInfo{
			Date: d.Format("2006-01-02"), Label: d.Format("2"),
			IsToday:   d.Equal(today),
			IsHoliday: hname != "", HolidayName: hname,
		})
		dayDates = append(dayDates, d)
	}

	var logins []string
	if userDepartmentStructure.Role == models.RoleManager {
		for _, s := range h.store.GetSubordinates(user.Login) {
			logins = append(logins, s.Login)
		}
	} else {
		logins = []string{user.Login}
	}

	var employees []EmpRowDTO
	var stats []EmpStatDTO

	for _, login := range logins {
		emp, ok := h.store.GetUser(login)
		if !ok {
			continue
		}

		allStages := h.store.GetStagesForUser(login, calStart)
		taskIDSet := map[string]bool{}
		for _, st := range allStages {
			taskIDSet[st.TaskID] = true
		}
		var taskIDs []string
		for id := range taskIDSet {
			taskIDs = append(taskIDs, id)
		}
		sort.Strings(taskIDs)

		var taskRows []TaskRowDTO
		for _, tid := range taskIDs {
			t, ok := h.store.GetTask(tid)
			if !ok {
				continue
			}
			var bars []StageBarDTO
			for _, st := range allStages {
				if st.TaskID != tid {
					continue
				}
				sd, ed, ok := workingDayRange(st.Start, st.End, dayDates)
				if !ok {
					continue
				}
				bar := StageBarDTO{
					StageID: st.ID, TaskID: st.TaskID, Name: st.Name,
					StageType: string(st.StageType), Status: string(st.Status),
					Color:       models.StageTypeColor(st.StageType),
					StatusColor: models.StageStatusColor(st.Status),
					StartDay:    sd, EndDay: ed,
					AssignedLogin: st.AssignedLogin,
					URLLink:       st.URLLink,
				}
				if st.Start != nil {
					bar.StartDate = st.Start.Format("02.01.2006")
				}
				if st.End != nil {
					bar.EndDate = st.End.Format("02.01.2006")
				}
				bars = append(bars, bar)
			}
			taskRows = append(taskRows, TaskRowDTO{
				TaskID: t.ID, Name: t.Name, EconomicEffect: t.EconomicEffect, Status: string(t.Stage),
				Color:               models.TaskStatusColor(t.Stage),
				HasDates:            len(bars) > 0,
				HasUnassignedStages: h.store.TaskHasUnassignedStages(tid),
				Stages:              bars,
			})
		}

		if len(taskRows) == 0 && login == user.Login && userDepartmentStructure.Role == models.RoleManager {
			continue
		}

		employees = append(employees, EmpRowDTO{
			Login: emp.Login, FullName: emp.FullName, Tasks: taskRows,
			Overload: calcOverloadByStages(allStages, dayDates),
		})

		var monthStats []MonthStatDTO
		for _, offset := range []int{0, 1} {
			ref := today.AddDate(0, offset, 0)
			hrs := calcStageMonthHours(allStages, ref, holidays)
			cls := "green"
			if hrs > 160 {
				cls = "red"
			} else if hrs > 120 {
				cls = "orange"
			}
			monthStats = append(monthStats, MonthStatDTO{Month: monthNames[ref.Month()-1], Hours: hrs, Class: cls})
		}
		stats = append(stats, EmpStatDTO{Login: emp.Login, FullName: emp.FullName, Months: monthStats})
	}

	// Virtual unassigned row
	if userDepartmentStructure.Role == models.RoleManager {
		unassignedStages, noStageTasks := h.store.GetStagesUnassignedForManager(user)

		taskIDSet := map[string]bool{}
		for _, st := range unassignedStages {
			taskIDSet[st.TaskID] = true
		}
		for _, tid := range noStageTasks {
			taskIDSet[tid] = true
		}

		if len(taskIDSet) > 0 {
			var taskIDs []string
			for id := range taskIDSet {
				taskIDs = append(taskIDs, id)
			}
			sort.Strings(taskIDs)

			var taskRows []TaskRowDTO
			for _, tid := range taskIDs {
				t, ok := h.store.GetTask(tid)
				if !ok {
					continue
				}

				isNoStage := true
				for _, st := range unassignedStages {
					if st.TaskID == tid {
						isNoStage = false
						break
					}
				}

				var bars []StageBarDTO
				for _, st := range unassignedStages {
					if st.TaskID != tid {
						continue
					}
					sd, ed, ok := workingDayRange(st.Start, st.End, dayDates)
					if !ok {
						continue
					}
					bar := StageBarDTO{
						StageID: st.ID, TaskID: st.TaskID, Name: st.Name,
						StageType: string(st.StageType), Status: string(st.Status),
						Color:       models.StageTypeColor(st.StageType),
						StatusColor: models.StageStatusColor(st.Status),
						StartDay:    sd, EndDay: ed,
						AssignedLogin: st.AssignedLogin,
						URLLink:       st.URLLink,
					}
					if st.Start != nil {
						bar.StartDate = st.Start.Format("02.01.2006")
					}
					if st.End != nil {
						bar.EndDate = st.End.Format("02.01.2006")
					}
					bars = append(bars, bar)
				}
				taskRows = append(taskRows, TaskRowDTO{
					TaskID: t.ID, Name: t.Name, EconomicEffect: t.EconomicEffect, Status: string(t.Stage),
					Color:    models.TaskStatusColor(t.Stage),
					HasDates: len(bars) > 0,
					NoStages: isNoStage,
					Stages:   bars,
				})
			}

			employees = append(employees, EmpRowDTO{
				Login: "__unassigned__", FullName: "Не распределено",
				IsVirtual: true, Tasks: taskRows,
				Overload: calcOverloadByStages(unassignedStages, dayDates),
			})

			var monthStats []MonthStatDTO
			for _, offset := range []int{0, 1} {
				ref := today.AddDate(0, offset, 0)
				hrs := calcStageMonthHours(unassignedStages, ref, holidays)
				cls := "green"
				if hrs > 160 {
					cls = "red"
				} else if hrs > 120 {
					cls = "orange"
				}
				monthStats = append(monthStats, MonthStatDTO{Month: monthNames[ref.Month()-1], Hours: hrs, Class: cls})
			}
			stats = append(stats, EmpStatDTO{Login: "__unassigned__", FullName: "Не распределено", Months: monthStats})
		}
	}

	jsonOK(w, CalendarDTO{Days: days, TodayIdx: todayIdx, Employees: employees, Stats: stats, Holidays: holidays})
}

func workingDayRange(start, end *time.Time, days []time.Time) (int, int, bool) {
	if len(days) == 0 {
		return 0, 0, false
	}
	loc := days[0].Location()
	dateFmt := func(t time.Time) string { return t.In(loc).Format("2006-01-02") }

	calFirst := dateFmt(days[0])
	calLast := dateFmt(days[len(days)-1])

	sDate := calFirst
	eDate := calLast
	if start != nil {
		sDate = dateFmt(*start)
	}
	if end != nil {
		eDate = dateFmt(*end)
	}

	if sDate > calLast || eDate < calFirst {
		return 0, 0, false
	}
	if sDate < calFirst {
		sDate = calFirst
	}
	if eDate > calLast {
		eDate = calLast
	}

	sd, ed := -1, -1
	for i, d := range days {
		dDate := dateFmt(d)
		if sd == -1 && dDate >= sDate {
			sd = i
		}
		if dDate <= eDate {
			ed = i
		}
	}
	if sd == -1 || ed == -1 || sd > ed {
		return 0, 0, false
	}
	return sd, ed, true
}

func calcOverloadByStages(stages []*models.Stage, days []time.Time) []OverloadDTO {
	if len(days) == 0 {
		return nil
	}
	loc := days[0].Location()
	dateFmt := func(t time.Time) string { return t.In(loc).Format("2006-01-02") }
	var out []OverloadDTO
	inOL, start := false, 0
	for i, d := range days {
		dDate := dateFmt(d)
		cnt := 0
		for _, st := range stages {
			if st.Start == nil || st.End == nil {
				continue
			}
			if dDate >= dateFmt(*st.Start) && dDate <= dateFmt(*st.End) {
				cnt++
			}
		}
		if cnt >= 3 {
			if !inOL {
				start = i
				inOL = true
			}
		} else if inOL {
			out = append(out, OverloadDTO{start, i - 1})
			inOL = false
		}
	}
	if inOL {
		out = append(out, OverloadDTO{start, len(days) - 1})
	}
	return out
}

func calcStageMonthHours(stages []*models.Stage, ref time.Time, holidays map[string]string) float64 {
	loc := ref.Location()
	ms := time.Date(ref.Year(), ref.Month(), 1, 0, 0, 0, 0, loc)
	me := ms.AddDate(0, 1, -1)
	var h float64
	for _, st := range stages {
		if st.Start == nil || st.End == nil {
			continue
		}
		// Normalize to local midnight so comparisons are timezone-consistent
		sy, sm, sd := st.Start.In(loc).Date()
		ey, em, ed := st.End.In(loc).Date()
		s := time.Date(sy, sm, sd, 0, 0, 0, 0, loc)
		e := time.Date(ey, em, ed, 0, 0, 0, 0, loc)
		if s.Before(ms) {
			s = ms
		}
		if e.After(me) {
			e = me
		}
		for d := s; !d.After(e); d = d.AddDate(0, 0, 1) {
			if isWorkday(d, holidays) {
				h += 8
			}
		}
	}
	return h
}

// ===================== TASKS =====================

func (h *Hendlers) Tasks(w http.ResponseWriter, r *http.Request) {
	user, _ := h.auth.GetCurrentUser(r)
	userDepartmentStructure, _ := h.store.GetUserDepartmentStructure(user)
	today := time.Now().Truncate(24 * time.Hour)
	calStart := time.Date(today.Year(), today.Month(), 1, 0, 0, 0, 0, today.Location())
	var tasks []*models.Task
	if userDepartmentStructure.Role == models.RoleManager {
		tasks = h.store.GetTasksForManager(user, calStart)
	} else {
		tasks = h.store.GetTasksForUser(user.Login, calStart)
	}
	sort.Slice(tasks, func(i, j int) bool { return tasks[i].ID < tasks[j].ID })
	jsonOK(w, tasks)
}

// TasksByUser — сервисный эндпоинт для внешнего сервиса navgit.
// Отдаёт задачи и этапы конкретного разработчика (не скоупится по вошедшему).
// Этапы несут Stage.ID (= JobId в Dev history 52290) — по нему navgit находит
// объекты задачи. Задачи включают только что закрытые (status='Готово') — это
// триггер merge ветки в общий репозиторий.
func (h *Hendlers) TasksByUser(w http.ResponseWriter, r *http.Request) {
	login := strings.Trim(strings.TrimPrefix(r.URL.Path, "/api/tasks/by-user/"), "/")
	if login == "" {
		jsonErr(w, "login required", 400)
		return
	}

	stages := h.store.GetStagesByAssignedLogin(login)

	seen := map[string]bool{}
	var tasks []*models.Task
	addTask := func(id string) {
		if id == "" || seen[id] {
			return
		}
		seen[id] = true
		if t, ok := h.store.GetTask(id); ok {
			tasks = append(tasks, t)
		}
	}
	// задачи, назначенные на дева напрямую
	for _, t := range h.store.GetTasksByAssignedLogin(login) {
		if !seen[t.ID] {
			seen[t.ID] = true
			tasks = append(tasks, t)
		}
	}
	// плюс родительские задачи этапов дева (назначение на уровне этапа)
	for _, st := range stages {
		addTask(st.TaskID)
	}

	sort.Slice(tasks, func(i, j int) bool { return tasks[i].ID < tasks[j].ID })
	jsonOK(w, map[string]interface{}{"tasks": tasks, "stages": stages})
}

func (h *Hendlers) TaskGet(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimPrefix(r.URL.Path, "/api/tasks/")
	t, ok := h.store.GetTask(id)
	if !ok {
		jsonErr(w, "not found", 404)
		return
	}
	stages := h.store.GetStagesForTask(id)
	sort.Slice(stages, func(i, j int) bool {
		if stages[i].Start == nil {
			return true
		}
		if stages[j].Start == nil {
			return false
		}
		return stages[i].Start.Before(*stages[j].Start)
	})
	comments := h.store.GetComments("task", id)
	jsonOK(w, map[string]interface{}{
		"task": t, "stages": stages, "comments": comments,
		"task_color":            models.TaskStatusColor(t.Stage),
		"stage_type_colors":     stageTypeColorMap(),
		"stage_status_colors":   stageStatusColorMap(),
		"has_unassigned_stages": h.store.TaskHasUnassignedStages(id),
	})
}

func (h *Hendlers) TaskCreate(w http.ResponseWriter, r *http.Request) {
	user, _ := h.auth.GetCurrentUser(r)
	userDepartmentStructure, _ := h.store.GetUserDepartmentStructure(user)
	var req struct {
		models.Task
		CreateDefaultStages bool `json:"create_default_stages"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		jsonErr(w, "bad request", 400)
		return
	}
	req.Task.ID = db.GenID("task")
	req.Task.InitiatorFullName = user.FullName
	req.Task.InitiatorDeptID = userDepartmentStructure.DepartmentID
	if err := h.store.CreateTask(&req.Task); err != nil {
		jsonErr(w, err.Error(), 500)
		return
	}
	if req.CreateDefaultStages {
		for _, st := range models.DefaultStages(req.Task.ID) {
			st.ID = db.GenID("stage")
			h.store.CreateStage(&st)
		}
	}
	jsonOK(w, req.Task)
}

func (h *Hendlers) TaskUpdate(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimPrefix(r.URL.Path, "/api/tasks/")
	existing, ok := h.store.GetTask(id)
	if !ok {
		jsonErr(w, "not found", 404)
		return
	}
	var body models.Task
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		jsonErr(w, "bad request", 400)
		return
	}
	body.ID = existing.ID
	body.InitiatorFullName = existing.InitiatorFullName
	body.InitiatorDeptID = existing.InitiatorDeptID
	body.CreatedAt = existing.CreatedAt
	if err := h.store.UpdateTask(&body); err != nil {
		jsonErr(w, err.Error(), 500)
		return
	}
	jsonOK(w, body)
}

func (h *Hendlers) TaskDelete(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimPrefix(r.URL.Path, "/api/tasks/")
	if err := h.store.DeleteTask(id); err != nil {
		jsonErr(w, err.Error(), 500)
		return
	}
	jsonOK(w, map[string]string{"status": "ok"})
}

// ===================== STAGES =====================

func (h *Hendlers) StageCreate(w http.ResponseWriter, r *http.Request) {
	var body models.Stage
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		jsonErr(w, "bad request", 400)
		return
	}
	body.ID = db.GenID("stage")
	if err := h.store.CreateStage(&body); err != nil {
		jsonErr(w, err.Error(), 500)
		return
	}
	jsonOK(w, body)
}

func (h *Hendlers) StageUpdate(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimPrefix(r.URL.Path, "/api/stages/")
	existing, ok := h.store.GetStage(id)
	if !ok {
		jsonErr(w, "not found", 404)
		return
	}
	var body models.Stage
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		jsonErr(w, "bad request", 400)
		return
	}
	body.ID = existing.ID
	body.TaskID = existing.TaskID
	body.CreatedAt = existing.CreatedAt
	if err := h.store.UpdateStage(&body); err != nil {
		jsonErr(w, err.Error(), 500)
		return
	}
	jsonOK(w, body)
}

func (h *Hendlers) StageDelete(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimPrefix(r.URL.Path, "/api/stages/")
	if err := h.store.DeleteStage(id); err != nil {
		jsonErr(w, err.Error(), 500)
		return
	}
	jsonOK(w, map[string]string{"status": "ok"})
}

// ===================== COMMENTS =====================

func (h *Hendlers) CommentAdd(w http.ResponseWriter, r *http.Request) {
	user, _ := h.auth.GetCurrentUser(r)
	var body struct {
		EntityType string `json:"entity_type"`
		EntityID   string `json:"entity_id"`
		Text       string `json:"text"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		jsonErr(w, "bad request", 400)
		return
	}
	if strings.TrimSpace(body.Text) == "" {
		jsonErr(w, "empty comment", 400)
		return
	}
	c := &models.Comment{
		ID:         db.GenID("comment"),
		EntityType: body.EntityType, EntityID: body.EntityID,
		AuthorLogin: user.Login, AuthorName: user.FullName,
		Text: strings.TrimSpace(body.Text),
	}
	if err := h.store.AddComment(c); err != nil {
		jsonErr(w, err.Error(), 500)
		return
	}
	jsonOK(w, c)
}

func (h *Hendlers) CommentDelete(w http.ResponseWriter, r *http.Request) {
	id := strings.TrimPrefix(r.URL.Path, "/api/comments/")
	if err := h.store.DeleteComment(id); err != nil {
		jsonErr(w, err.Error(), 500)
		return
	}
	jsonOK(w, map[string]string{"status": "ok"})
}

// ===================== HOLIDAYS =====================

func (h *Hendlers) HolidaysGet(w http.ResponseWriter, r *http.Request) {
	today := time.Now()
	holidays := map[string]string{}
	for _, yr := range []int{today.Year(), today.Year() + 1} {
		for k, v := range h.store.GetHolidays(yr) {
			holidays[k] = v
		}
	}
	jsonOK(w, holidays)
}

// ===================== REFERENCE =====================

func (h *Hendlers) RefUsers(w http.ResponseWriter, r *http.Request) {
	user, _ := h.auth.GetCurrentUser(r)
	userDepartmentStructure, _ := h.store.GetUserDepartmentStructure(user)
	type UserDTO struct {
		Login    string `json:"login"`
		FullName string `json:"full_name"`
		Role     string `json:"role"`
	}
	var out []UserDTO
	if userDepartmentStructure.Role == models.RoleManager {
		out = append(out, UserDTO{user.Login, user.FullName + " (я)", string(userDepartmentStructure.Role)})
		for _, u := range h.store.GetSubordinates(user.Login) {
			uds, _ := h.store.GetUserDepartmentStructure(u)
			out = append(out, UserDTO{u.Login, u.FullName, string(uds.Role)})
		}
	} else {
		out = append(out, UserDTO{user.Login, user.FullName, string(userDepartmentStructure.Role)})
	}
	jsonOK(w, out)
}

func (h *Hendlers) RefDepts(w http.ResponseWriter, r *http.Request) {
	jsonOK(w, h.store.GetAllDepartments())
}

func (h *Hendlers) RefColors(w http.ResponseWriter, r *http.Request) {
	jsonOK(w, map[string]interface{}{
		"task_statuses": taskStatusColorMap(), "stage_types": stageTypeColorMap(),
		"stage_statuses":     stageStatusColorMap(),
		"all_task_statuses":  models.AllTaskStatuses(),
		"all_stage_types":    models.AllStageTypes(),
		"all_stage_statuses": models.AllStageStatuses(),
	})
}

func taskStatusColorMap() map[models.TaskStatus]string {
	m := map[models.TaskStatus]string{}
	for _, s := range models.AllTaskStatuses() {
		m[s] = models.TaskStatusColor(s)
	}
	return m
}

func stageTypeColorMap() map[models.TaskStage]string {
	m := map[models.TaskStage]string{}
	for _, s := range models.AllStageTypes() {
		m[s] = models.StageTypeColor(s)
	}
	return m
}

func stageStatusColorMap() map[models.TaskStageStatus]string {
	m := map[models.TaskStageStatus]string{}
	for _, s := range models.AllStageStatuses() {
		m[s] = models.StageStatusColor(s)
	}
	return m
}
