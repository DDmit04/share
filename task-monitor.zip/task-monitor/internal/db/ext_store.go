package db

import (
	"database/sql"
	"fmt"
	"sync"
	"taskmon/internal/models"
	"time"

	mssql "github.com/microsoft/go-mssqldb"
)

const (
	TaskSelect = `SELECT TOP 100
		sc.[id],
		'['+sc.[title]+'] ' + sc.[shortDescr] AS [name],
		sc.[startTime] AS [start],
		sc.[deadLineTime] AS [end],
		'https://help.agrohold.ru/sd/operator/#uuid:serviceCall$'+CAST(sc.[id] as nvarchar) AS [url_link],
		CASE
			WHEN sc.[state] IN ('predIT', 'negotSOH') then 'Оценка'
			WHEN sc.[state] = 'formationCAB' then 'Экономисты'
			WHEN sc.[state] = 'setResposible' then 'Определение ответственного'
			WHEN sc.[state] IN ('programming','inprogress') then 'В работе'
			WHEN sc.[state] IN ('closed','resolved') then 'Готово'
		END as [status],
		i.[title] AS [initiator_full_name],
		'' AS [initiator_dept_id],
		'nav' AS [executor_dept_id],
		LOWER(r.[login])+'@agrohold.ru' AS [assigned_login],
		sc.[creation_date] AS [created_at],
		sc.[last_modified_date] AS [updated_at],
	 	CAST(CAST(sc.[changeRequest$ocencaEffecta] AS BIGINT) AS VARCHAR(20)) AS [economic_effect]
	FROM [NAUMEN10-DB].[naumensd4].[dbo].[tbl_servicecall] as sc
	LEFT JOIN [NAUMEN10-DB].[naumensd4].[dbo].[tbl_employee] i ON i.[id] = sc.[clientEmployee_id]	 
	LEFT JOIN [NAUMEN10-DB].[naumensd4].[dbo].[tbl_employee] r ON r.[id] = sc.[responsibleEmployee_id] `

	StageSelect = `SELECT TOP 100
t.[id] AS [id],
t.[serviceCall] AS [task_id],
ISNULL(LOWER(r.[login])+'@agrohold.ru','') AS [assigned_login],
t.[title] AS [name],
ISNULL(t.[startTask], t.[stateStartTime]) AS [start],
t.[deadline] AS [end],
'https://help.agrohold.ru/sd/operator/#uuid:task$'+CAST(t.[id] as nvarchar) AS [url_link],
CASE
	WHEN t.[state] IN ('registered', 'waiting') then 'В Плане'
	WHEN t.[state] = 'setResposible' then 'Определение ответственного'
	WHEN t.[state] = 'inprogress' then 'В работе'
	WHEN t.[state] = 'closed' then 'Готово'
	WHEN t.[state] = 'canceled' then 'Отмена'
END AS [status],
CASE
	WHEN t.[title] = 'Обследование' then 'Обследование'
	WHEN t.[title] = 'Разработка технического задания (ТЗ) на изменение' then 'Написание ТЗ'
	WHEN t.[title] = 'Согласование с архитектором' then 'Согласование с архитектором'
	WHEN t.[title] = 'Реализация изменения по ТЗ' then 'Разработка'
	WHEN t.[title] = 'Тестирование изменения консультантом' then 'Тестирование'
	WHEN t.[title] = 'Подготовка краткого описания разработки' then 'Написание тех. док.'
	WHEN t.[title] = 'Перенос изменения в продуктовую среду' then 'Разливка'
	ELSE IIF(t.[case_id] = 'ReqProgramming', 'Разработка', 'Обследование')
END AS [stage_type],
t.[creation_date] AS [created_at],
t.[last_modified_date] AS [updated_at]
FROM [NAUMEN10-DB].[naumensd4].[dbo].[tbl_task] as t
LEFT JOIN [NAUMEN10-DB].[naumensd4].[dbo].[tbl_employee] r ON r.[id] = t.[responsibleEmployee_id]`
)

type ExtStore struct {
	mu sync.Mutex
}

func NewExtStore() (*ExtStore, error) {
	s := &ExtStore{}
	return s, nil
}

func (es *ExtStore) conn() (*sql.DB, error) {
	psqlInfo := fmt.Sprintf("server=%s;"+
		"database=%s;"+
		"Trusted_Connection=True;"+
		"TrustServerCertificate=true;"+
		"Encrypt=False",
		"R2TEST",
		"Development3",
	)
	connector, _ := mssql.NewConnector(psqlInfo)
	db := sql.OpenDB(connector)
	return db, db.Ping()
}

func (se *ExtStore) query(query string, args ...any) (*sql.Rows, *sql.DB, error) {
	db, err := se.conn()
	if err != nil {
		return nil, nil, err
	}
	rows, err := db.Query(query, args...)
	if err != nil {
		db.Close()
		return nil, nil, err
	}
	return rows, db, nil
}

func parseExtTime(s *string) *time.Time {
	if s == nil || *s == "" {
		return nil
	}
	t, err := time.Parse("2006-01-02 15:04:05.000", *s)
	if err != nil {
		return nil
	}
	return &t
}

func ReadTask(row *sql.Rows) *models.Task {
	t := &models.Task{}
	var startStr, endStr, sca, sua, effect *string
	row.Scan(
		&t.ID,
		&t.Name,
		&startStr,
		&endStr,
		&t.URLLink,
		&t.Stage,
		&t.InitiatorFullName,
		&t.InitiatorDeptID,
		&t.ExecutorDeptID,
		&t.AssignedLogin,
		&sca,
		&sua,
		&effect,
	)
	if effect != nil {
		t.EconomicEffect = *effect
	}
	t.Start = parseTime(startStr)
	t.End = parseTime(endStr)
	if sca != nil {
		t.CreatedAt = *parseTime(sca)
	}

	if sua != nil {
		t.UpdatedAt = *parseTime(sua)
	}
	return t
}

func (se *ExtStore) GetTasks() ([]*models.Task, error) {
	rows, db, err := se.query(
		TaskSelect +
			`WHERE sc.[case_id] IN ('changeRequest')
		AND NOT sc.[responsibleEmployee_id] IS NULL
		AND sc.[sysIzm] = 5623601
	ORDER BY sc.[id]`)

	if err != nil {
		return nil, err
	}
	defer db.Close()
	defer rows.Close()
	var out []*models.Task
	for rows.Next() {
		out = append(out, ReadTask(rows))
	}

	return out, nil
}

func (se *ExtStore) GetTasksFromDateToChan(ch chan<- *models.Task, from time.Time) error {
	defer close(ch)

	rows, db, err := se.query(
		TaskSelect +
			`WHERE sc.[case_id] IN ('changeRequest')
			AND NOT sc.[responsibleEmployee_id] IS NULL
			AND sc.[sysIzm] = 5623601
			AND sc.[last_modified_date] > '` + from.Format(time.DateTime+`.000`) + `'
		ORDER BY sc.[last_modified_date] ASC`,
	)
	if err != nil {
		return err
	}

	defer db.Close()
	defer rows.Close()
	for rows.Next() {
		ch <- ReadTask(rows)
	}

	return nil
}

func ReadStage(row *sql.Rows) *models.Stage {
	s := &models.Stage{}
	var startStr, endStr, sca, sua *string
	row.Scan(
		&s.ID,
		&s.TaskID,
		&s.AssignedLogin,
		&s.Name,
		&startStr,
		&endStr,
		&s.URLLink,
		&s.Status,
		&s.StageType,
		&sca,
		&sua,
	)
	s.Start = parseTime(startStr)
	s.End = parseTime(endStr)
	if sca != nil {
		s.CreatedAt = *parseTime(sca)
	} else {
		s.CreatedAt = time.Now()
	}
	if sua != nil {
		s.UpdatedAt = *parseTime(sua)
	} else {
		s.UpdatedAt = time.Now()
	}
	return s
}

func (se *ExtStore) GetStagesByTask(task models.Task) ([]*models.Stage, error) {
	rows, db, err := se.query(
		StageSelect +
			`WHERE t.[serviceCall] = '` + task.ID + `' AND NOT t.[responsibleEmployee_id] IS NULL`,
	)

	if err != nil {
		return nil, err
	}
	defer db.Close()
	defer rows.Close()
	var out []*models.Stage
	for rows.Next() {
		out = append(out, ReadStage(rows))
	}

	return out, nil
}

func (se *ExtStore) GetStagesFromDateToChan(ch chan<- *models.Stage, from time.Time) error {
	defer close(ch)

	rows, db, err := se.query(
		StageSelect +
			`WHERE EXISTS(
	SELECT sc.* FROM [NAUMEN10-DB].[naumensd4].[dbo].[tbl_servicecall] as sc
	WHERE sc.[id] = t.[serviceCall]
	AND sc.[sysIzm] = 5623601
)
AND t.[last_modified_date] > '` + from.Format(time.DateTime+`.000`) + `'
ORDER BY t.[last_modified_date] ASC`,
	)
	if err != nil {
		return err
	}

	defer db.Close()
	defer rows.Close()
	for rows.Next() {
		ch <- ReadStage(rows)
	}

	return nil
}
