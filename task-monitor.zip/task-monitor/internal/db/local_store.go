package db

import (
	"database/sql"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"taskmon/internal/models"
	"time"

	"github.com/google/uuid"
	_ "modernc.org/sqlite"
)

const dbVersion = 4

type LocalStore struct {
	mu       sync.Mutex
	name     string
	sessions map[uuid.UUID]*models.UthorizedLogin
}

func NewLocalStore(dbPath string) (*LocalStore, error) {
	dir := filepath.Dir(dbPath)
	err := os.MkdirAll(dir, 0755)
	if err != nil {
		return nil, err
	}
	s := &LocalStore{name: dbPath, sessions: make(map[uuid.UUID]*models.UthorizedLogin)}
	if err := s.initDB(); err != nil {
		return nil, err
	}
	return s, nil
}

func (s *LocalStore) conn() (*sql.DB, error) {
	return sql.Open("sqlite", s.name+"?_journal_mode=WAL&_foreign_keys=on")
}

func (s *LocalStore) exec(query string, args ...any) (sql.Result, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	db, err := s.conn()
	if err != nil {
		return nil, err
	}
	defer db.Close()
	return db.Exec(query, args...)
}

func (s *LocalStore) query(query string, args ...any) (*sql.Rows, *sql.DB, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	db, err := s.conn()
	if err != nil {
		return nil, nil, err
	}
	rows, err := db.Query(query, args...)
	if err != nil {
		db.Close()
		return nil, nil, err
	}
	return rows, db, nil
}

// ---- Init ----

func (s *LocalStore) initDB() error {
	db, err := s.conn()
	if err != nil {
		return err
	}
	defer db.Close()

	// Схема актуальной версии создаётся аддитивно (IF NOT EXISTS): новые
	// таблицы появятся, существующие не трогаются.
	if err := createTables(db); err != nil {
		return err
	}

	var ver int
	err = db.QueryRow("SELECT ver FROM _version LIMIT 1").Scan(&ver)
	switch {
	case errors.Is(err, sql.ErrNoRows):
		// Свежая база: схема уже актуальная, фиксируем версию.
		if _, err := db.Exec(`INSERT INTO _version (ver) VALUES (?)`, dbVersion); err != nil {
			return err
		}
	case err != nil:
		return err
	default:
		// Существующая база: пошагово доводим схему до актуальной версии.
		if ver < dbVersion {
			if err := s.applyMigrations(db, ver, dbVersion); err != nil {
				return err
			}
		}
		if ver != dbVersion {
			if _, err := db.Exec(`UPDATE _version SET ver = ?`, dbVersion); err != nil {
				return err
			}
		}
	}

	// Индексы создаются ПОСЛЕ миграций столбцов: они могут ссылаться на
	// столбцы, добавленные шагами миграции.
	if err := createIndexes(db); err != nil {
		return err
	}
	return s.seed(db)
}

// applyMigrations последовательно переводит существующую базу с версии from на
// to. migrations[i] — шаг с версии i на i+1 (0-й шаг не нужен: свежая база
// сразу создаётся в актуальной схеме). Каждый шаг аддитивный и идемпотентный.
func (s *LocalStore) applyMigrations(db *sql.DB, from, to int) error {
	migrations := []func() error{
		0: nil,
		// v1 -> v2, v2 -> v3: исторические правки схемы (ранее фиксировались
		// пересозданием базы, отдельных шагов не требуют).
		1: func() error { return nil },
		2: func() error { return nil },
		// v3 -> v4: экономический эффект задачи.
		3: func() error {
			return ensureColumns(db, "tasks", map[string]string{
				"economic_effect": "TEXT NOT NULL DEFAULT ''",
			})
		},
	}

	for v := from; v < to; v++ {
		if v >= len(migrations) || migrations[v] == nil {
			continue
		}
		if err := migrations[v](); err != nil {
			return fmt.Errorf("миграция v%d -> v%d: %w", v, v+1, err)
		}
	}
	return nil
}

// ensureColumns аддитивно добавляет недостающие столбцы (для баз предыдущих
// версий).
func ensureColumns(db *sql.DB, table string, cols map[string]string) error {
	rows, err := db.Query(`PRAGMA table_info(` + table + `)`)
	if err != nil {
		return err
	}
	existing := map[string]bool{}
	for rows.Next() {
		var cid, notnull, pk int
		var name, ctype string
		var dflt sql.NullString
		if err := rows.Scan(&cid, &name, &ctype, &notnull, &dflt, &pk); err != nil {
			rows.Close()
			return err
		}
		existing[name] = true
	}
	rows.Close()
	for name, def := range cols {
		if existing[name] {
			continue
		}
		if _, err := db.Exec(`ALTER TABLE ` + table + ` ADD COLUMN ` + name + ` ` + def); err != nil {
			return err
		}
	}
	return nil
}

func createTables(db *sql.DB) error {
	queries := []string{
		`CREATE TABLE IF NOT EXISTS _version (ver INTEGER PRIMARY KEY)`,

		`CREATE TABLE IF NOT EXISTS departments (
			id TEXT PRIMARY KEY,
			name TEXT NOT NULL,
			parent_id TEXT DEFAULT ''
		)`,

		`CREATE TABLE IF NOT EXISTS users (
			login TEXT PRIMARY KEY,
			full_name TEXT NOT NULL
		)`,

		`CREATE TABLE IF NOT EXISTS department_structure (
			login TEXT NOT NULL DEFAULT '',
			department_id TEXT NOT NULL DEFAULT '',
			role TEXT NOT NULL DEFAULT '',
			PRIMARY KEY (login)
		)`,

		`CREATE TABLE IF NOT EXISTS tasks (
			id TEXT PRIMARY KEY,
			name TEXT NOT NULL,
			economic_effect TEXT NOT NULL DEFAULT '',
			start_date TEXT DEFAULT NULL,
			end_date TEXT DEFAULT NULL,
			url_link TEXT DEFAULT '',
			status TEXT NOT NULL DEFAULT 'Распределение',
			initiator_full_name TEXT DEFAULT '',
			initiator_dept_id TEXT DEFAULT '',
			executor_dept_id TEXT DEFAULT '',
			assigned_login TEXT DEFAULT '',
			created_at TEXT NOT NULL,
			updated_at TEXT NOT NULL
		)`,

		`CREATE TABLE IF NOT EXISTS stages (
			id TEXT NOT NULL,
			task_id TEXT NOT NULL,
			assigned_login TEXT DEFAULT '',
			name TEXT NOT NULL,
			start_date TEXT DEFAULT NULL,
			end_date TEXT DEFAULT NULL,
			url_link TEXT DEFAULT '',
			status TEXT NOT NULL DEFAULT 'В Плане',
			stage_type TEXT NOT NULL DEFAULT 'Обследование',
			created_at TEXT NOT NULL,
			updated_at TEXT NOT NULL,
			PRIMARY KEY (id, task_id),
			FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE
		)`,

		`CREATE TABLE IF NOT EXISTS comments (
			id TEXT PRIMARY KEY,
			entity_type TEXT NOT NULL,
			entity_id TEXT NOT NULL,
			author_login TEXT NOT NULL,
			author_name TEXT NOT NULL,
			text TEXT NOT NULL,
			created_at TEXT NOT NULL
		)`,

		`CREATE TABLE IF NOT EXISTS holidays (
			date TEXT NOT NULL,
			name TEXT NOT NULL,
			country TEXT NOT NULL DEFAULT 'RU',
			PRIMARY KEY(date, country)
		)`,

		`CREATE TABLE IF NOT EXISTS ext_table_stamp (
			id TEXT NOT NULL,
			stamp TEXT NOT NULL,
			PRIMARY KEY(id)
		)`,
	}
	return execAll(db, queries)
}

// createIndexes создаёт индексы. Вызывается ПОСЛЕ миграций столбцов (индексы
// могут ссылаться на добавленные столбцы).
func createIndexes(db *sql.DB) error {
	return execAll(db, []string{
		`CREATE INDEX IF NOT EXISTS idx_comments_entity ON comments(entity_type, entity_id)`,
	})
}

func execAll(db *sql.DB, queries []string) error {
	tx, err := db.Begin()
	if err != nil {
		return err
	}
	for _, q := range queries {
		if _, err := tx.Exec(q); err != nil {
			tx.Rollback()
			return fmt.Errorf("query failed: %s — %w", q[:min(len(q), 60)], err)
		}
	}
	return tx.Commit()
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func (s *LocalStore) seed(db *sql.DB) error {
	now := time.Now()

	/*
		depts := [][]string{
			{"dept-it", "ИТ Департамент", ""},
			{"dept-dev", "Отдел разработки", "dept-it"},
			{"dept-qa", "Отдел тестирования", "dept-it"},
		}
		for _, d := range depts {
			db.Exec(`INSERT INTO departments (id,name,parent_id) VALUES (?,?,?)`, d[0], d[1], d[2])
		}

		users := [][]string{
			{"director", "Иванов Иван Иванович", "dept-it", "manager", ""},
			{"dev_manager", "Петров Пётр Петрович", "dept-dev", "manager", "director"},
			{"qa_manager", "Сидорова Анна Сергеевна", "dept-qa", "manager", "director"},
			{"dev1", "Козлов Алексей Владимирович", "dept-dev", "employee", "dev_manager"},
			{"dev2", "Новикова Мария Андреевна", "dept-dev", "employee", "dev_manager"},
			{"qa1", "Морозов Дмитрий Олегович", "dept-qa", "employee", "qa_manager"},
		}
		for _, u := range users {
			db.Exec(`INSERT INTO users (login,password_hash,full_name,department_id,role,manager_login) VALUES (?,?,?,?,?,?)`,
				u[0], u[1], u[2], u[3], u[4], u[5])
		}
	*/

	// Seed Russian holidays for current year
	yr := now.Year()
	holidays := []struct{ date, name string }{
		{fmt.Sprintf("%d-01-01", yr), "Новый год"},
		{fmt.Sprintf("%d-01-02", yr), "Новогодние каникулы"},
		{fmt.Sprintf("%d-01-03", yr), "Новогодние каникулы"},
		{fmt.Sprintf("%d-01-07", yr), "Рождество Христово"},
		{fmt.Sprintf("%d-02-23", yr), "День защитника Отечества"},
		{fmt.Sprintf("%d-03-08", yr), "Международный женский день"},
		{fmt.Sprintf("%d-05-01", yr), "Праздник Весны и Труда"},
		{fmt.Sprintf("%d-05-09", yr), "День Победы"},
		{fmt.Sprintf("%d-06-12", yr), "День России"},
		{fmt.Sprintf("%d-11-04", yr), "День народного единства"},
	}
	for _, h := range holidays {
		db.Exec(`INSERT OR IGNORE INTO holidays (date,name,country) VALUES (?,?,'RU')`, h.date, h.name)
	}
	// seed next year too
	yr++
	for _, h := range holidays {
		adjusted := fmt.Sprintf("%d%s", yr, h.date[4:])
		db.Exec(`INSERT OR IGNORE INTO holidays (date,name,country) VALUES (?,?,'RU')`, adjusted, h.name)
	}

	return nil
}

func parseTime(s *string) *time.Time {
	if s == nil || *s == "" {
		return nil
	}
	t, err := time.Parse(time.RFC3339, *s)
	if err != nil {
		t, err = time.Parse("2006-01-02", *s)
		if err != nil {
			return nil
		}
	}
	return &t
}

// ---- Users ----

func (s *LocalStore) GetUser(login string) (*models.User, bool) {
	rows, db, err := s.query(`SELECT login, full_name FROM users WHERE login=?`, login)
	if err != nil {
		return nil, false
	}
	defer db.Close()
	defer rows.Close()
	if rows.Next() {
		u := &models.User{}
		rows.Scan(&u.Login, &u.FullName)
		return u, true
	}
	return nil, false
}

func (s *LocalStore) GetSubordinates(managerLogin string) []*models.User {
	rows, db, err := s.query(
		`SELECT 
			u.login,
			u.full_name
		FROM department_structure as ds1
		INNER JOIN  department_structure as ds2 ON ds2.department_id = ds1.department_id
		INNER JOIN users as u ON u.login = ds2.login
		WHERE ds1.role = 'manager' AND ds1.login = ?
		ORDER BY u.login`,
		managerLogin,
	)

	if err != nil {
		return nil
	}
	defer db.Close()
	defer rows.Close()
	var out []*models.User
	for rows.Next() {
		u := &models.User{}
		rows.Scan(&u.Login, &u.FullName)
		out = append(out, u)
	}
	return out
}

// ---- Departments ----

func (s *LocalStore) GetAllDepartments() []*models.Department {
	rows, db, err := s.query(`SELECT id,name,parent_id FROM departments ORDER BY name`)
	if err != nil {
		return nil
	}
	defer db.Close()
	defer rows.Close()
	var out []*models.Department
	for rows.Next() {
		d := &models.Department{}
		rows.Scan(&d.ID, &d.Name, &d.ParentID)
		out = append(out, d)
	}
	return out
}

func (ls *LocalStore) GetUserDepartment(user *models.User) (*models.Department, error) {
	rows, db, err := ls.query(
		`SELECT 
			d.*
		FROM department_structure as ds
		INNER JOIN departments as d ON d.id = ds.department_id
		WHERE ds.login = ?`,
		user.Login,
	)
	if err != nil {
		return nil, err
	}
	defer db.Close()
	defer rows.Close()
	if rows.Next() {
		d := &models.Department{}
		rows.Scan(&d.ID, &d.Name, &d.ParentID)
		return d, nil
	}
	return nil, errors.New("Department of user [" + user.Login + "] not find")
}

func (ls *LocalStore) GetUserDepartmentStructure(user *models.User) (*models.DepartmentStructure, error) {
	rows, db, err := ls.query(
		`SELECT 
			ds.*
		FROM department_structure as ds
		WHERE ds.login = ?`,
		user.Login,
	)
	if err != nil {
		return nil, err
	}
	defer db.Close()
	defer rows.Close()
	if rows.Next() {
		d := &models.DepartmentStructure{}
		rows.Scan(&d.DepartmentID, &d.Login, &d.Role)
		return d, nil
	}
	return nil, errors.New("DepartmentStructure of user [" + user.Login + "] not find")
}

// ---- Holidays ----

func (s *LocalStore) GetHolidays(year int) map[string]string {
	rows, db, err := s.query(`SELECT date,name FROM holidays WHERE country='RU' AND date LIKE ?`, fmt.Sprintf("%d%%", year))
	if err != nil {
		return nil
	}
	defer db.Close()
	defer rows.Close()
	m := map[string]string{}
	for rows.Next() {
		var date, name string
		rows.Scan(&date, &name)
		m[date] = name
	}
	return m
}

func (s *LocalStore) SetHoliday(date, name string) error {
	_, err := s.exec(`INSERT OR REPLACE INTO holidays (date,name,country) VALUES (?,'RU')`, date, name)
	return err
}

func (s *LocalStore) DeleteHoliday(date string) error {
	_, err := s.exec(`DELETE FROM holidays WHERE date=? AND country='RU'`, date)
	return err
}

// ---- Tasks ----

func scanTask(rows *sql.Rows) *models.Task {
	t := &models.Task{}
	var startStr, endStr, sca, sua *string
	rows.Scan(&t.ID, &t.Name, &startStr, &endStr, &t.URLLink, &t.Stage,
		&t.InitiatorFullName, &t.InitiatorDeptID, &t.ExecutorDeptID, &t.AssignedLogin, &sca, &sua, &t.EconomicEffect)
	t.Start = parseTime(startStr)
	t.End = parseTime(endStr)
	t.CreatedAt = *parseTime(sca)
	t.UpdatedAt = *parseTime(sua)
	return t
}

func (s *LocalStore) GetTask(id string) (*models.Task, bool) {
	rows, db, err := s.query(`SELECT id,name,start_date,end_date,url_link,status,initiator_full_name,initiator_dept_id,executor_dept_id,assigned_login,created_at,updated_at,economic_effect FROM tasks WHERE id=?`, id)
	if err != nil {
		return nil, false
	}
	defer db.Close()
	defer rows.Close()
	if rows.Next() {
		return scanTask(rows), true
	}
	return nil, false
}

func (s *LocalStore) ExistsTask(id string) (bool, error) {
	rows, db, err := s.query(`SELECT 1 FROM tasks WHERE id=?`, id)
	if err != nil {
		return false, err
	}
	defer db.Close()
	defer rows.Close()
	if rows.Next() {
		return true, err
	}
	return false, err
}

func (s *LocalStore) GetTasksForUser(login string, oldestDeadLine time.Time) []*models.Task {
	rows, db, err := s.query(`SELECT id,name,start_date,end_date,url_link,status,initiator_full_name,initiator_dept_id,executor_dept_id,assigned_login,created_at,updated_at,economic_effect FROM tasks WHERE assigned_login=? AND (status != 'Готово' AND end_date <?) OR end_date >=?) ORDER BY id`,
		login,
		oldestDeadLine.Format(time.RFC3339),
		oldestDeadLine.Format(time.RFC3339),
	)

	if err != nil {
		return nil
	}
	defer db.Close()
	defer rows.Close()
	var out []*models.Task
	for rows.Next() {
		out = append(out, scanTask(rows))
	}
	return out
}

// GetTasksByAssignedLogin возвращает все задачи, назначенные на логин
// (без фильтра по дедлайну/статусу). Используется сервисным API /api/tasks/by-user
// внешним сервисом navgit, которому нужны в т.ч. только что закрытые задачи.
func (s *LocalStore) GetTasksByAssignedLogin(login string) []*models.Task {
	rows, db, err := s.query(`SELECT id,name,start_date,end_date,url_link,status,initiator_full_name,initiator_dept_id,executor_dept_id,assigned_login,created_at,updated_at,economic_effect FROM tasks WHERE assigned_login=? ORDER BY id`, login)
	if err != nil {
		return nil
	}
	defer db.Close()
	defer rows.Close()
	var out []*models.Task
	for rows.Next() {
		out = append(out, scanTask(rows))
	}
	return out
}

func (s *LocalStore) GetTasksForManager(user *models.User, oldestDeadLine time.Time) []*models.Task {
	department, err := s.GetUserDepartment(user)
	if err != nil {
		return nil
	}
	rows, db, err := s.query(`
		SELECT id,name,start_date,end_date,url_link,status,initiator_full_name,initiator_dept_id,executor_dept_id,assigned_login,created_at,updated_at,economic_effect
		FROM tasks
		WHERE assigned_login IN (SELECT login FROM users WHERE manager_login=?)
		   OR assigned_login = ?
		   OR (assigned_login = '' AND executor_dept_id = ?)
		   AND ((status != 'Готово' AND end_date <?) OR end_date >=?)
		ORDER BY id`,
		user.Login,
		user.Login,
		department.ID,
		oldestDeadLine.Format(time.RFC3339),
		oldestDeadLine.Format(time.RFC3339),
	)
	if err != nil {
		return nil
	}
	defer db.Close()
	defer rows.Close()
	var out []*models.Task
	for rows.Next() {
		out = append(out, scanTask(rows))
	}
	return out
}

func (s *LocalStore) CreateTask(t *models.Task) error {
	now := time.Now()
	t.CreatedAt = now
	t.UpdatedAt = now
	var ss, se interface{}
	if t.Start != nil {
		ss = t.Start.Format(time.RFC3339)
	}
	if t.End != nil {
		se = t.End.Format(time.RFC3339)
	}
	_, err := s.exec(`INSERT INTO tasks (id,name,start_date,end_date,url_link,status,initiator_full_name,initiator_dept_id,executor_dept_id,assigned_login,created_at,updated_at,economic_effect)
		VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
		t.ID, t.Name, ss, se, t.URLLink, t.Stage, t.InitiatorFullName, t.InitiatorDeptID, t.ExecutorDeptID, t.AssignedLogin,
		t.CreatedAt.Format(time.RFC3339), t.UpdatedAt.Format(time.RFC3339), t.EconomicEffect)
	return err
}

func (s *LocalStore) UpdateTask(t *models.Task) error {
	var ss, se interface{}
	t.UpdatedAt = time.Now()
	if t.Start != nil {
		ss = t.Start.Format(time.RFC3339)
	}
	if t.End != nil {
		se = t.End.Format(time.RFC3339)
	}
	_, err := s.exec(`UPDATE tasks SET name=?,start_date=?,end_date=?,url_link=?,status=?,executor_dept_id=?,assigned_login=?,economic_effect=?,updated_at=? WHERE id=?`,
		t.Name, ss, se, t.URLLink, t.Stage, t.ExecutorDeptID, t.AssignedLogin, t.EconomicEffect, t.UpdatedAt.Format(time.RFC3339), t.ID)
	return err
}

func (s *LocalStore) SaveTask(t *models.Task) error {
	now := time.Now()
	if t.CreatedAt.IsZero() {
		t.CreatedAt = now
	}
	if t.CreatedAt.IsZero() {
		t.UpdatedAt = now
	}
	var ss, se interface{}
	if t.Start != nil {
		ss = t.Start.Format(time.RFC3339)
	}
	if t.End != nil {
		se = t.End.Format(time.RFC3339)
	}
	_, err := s.exec(`REPLACE INTO tasks (id,name,start_date,end_date,url_link,status,initiator_full_name,initiator_dept_id,executor_dept_id,assigned_login,created_at,updated_at,economic_effect)
		VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
		t.ID, t.Name, ss, se, t.URLLink, t.Stage, t.InitiatorFullName, t.InitiatorDeptID, t.ExecutorDeptID, t.AssignedLogin,
		t.CreatedAt.Format(time.RFC3339), t.UpdatedAt.Format(time.RFC3339), t.EconomicEffect)
	return err
}

func (s *LocalStore) DeleteTask(id string) error {
	_, err := s.exec(`DELETE FROM tasks WHERE id=?`, id)
	return err
}

// ---- Stages ----

func scanStage(rows *sql.Rows) *models.Stage {
	st := &models.Stage{}
	var ss, se, sca, sua *string
	rows.Scan(&st.ID, &st.TaskID, &st.AssignedLogin, &st.Name, &ss, &se, &st.URLLink, &st.Status, &st.StageType, &sca, &sua)
	st.Start = parseTime(ss)
	st.End = parseTime(se)
	st.CreatedAt = *parseTime(sca)
	st.UpdatedAt = *parseTime(sua)
	return st
}

func (s *LocalStore) GetStage(id string) (*models.Stage, bool) {
	rows, db, err := s.query(`SELECT id,task_id,assigned_login,name,start_date,end_date,url_link,status,stage_type,created_at,updated_at FROM stages WHERE id=?`, id)
	if err != nil {
		return nil, false
	}
	defer db.Close()
	defer rows.Close()
	if rows.Next() {
		return scanStage(rows), true
	}
	return nil, false
}

func (s *LocalStore) GetStagesForTask(taskID string) []*models.Stage {
	rows, db, err := s.query(`SELECT id,task_id,assigned_login,name,start_date,end_date,url_link,status,stage_type,created_at,updated_at FROM stages WHERE task_id=? AND status != 'Отмена' ORDER BY COALESCE(start_date,'9999') ASC`, taskID)
	if err != nil {
		return nil
	}
	defer db.Close()
	defer rows.Close()
	var out []*models.Stage
	for rows.Next() {
		out = append(out, scanStage(rows))
	}
	return out
}

func (s *LocalStore) GetStagesForUser(login string, oldestDeadLine time.Time) []*models.Stage {
	rows, db, err := s.query(`SELECT id,task_id,assigned_login,name,start_date,end_date,url_link,status,stage_type,created_at,updated_at FROM stages WHERE assigned_login=? AND ((status != 'Готово' AND end_date <?) OR end_date >=?) AND status != 'Отмена' ORDER BY COALESCE(start_date,'9999') ASC`, login, oldestDeadLine.Format(time.RFC3339), oldestDeadLine.Format(time.RFC3339))
	if err != nil {
		return nil
	}
	defer db.Close()
	defer rows.Close()
	var out []*models.Stage
	for rows.Next() {
		out = append(out, scanStage(rows))
	}
	return out
}

// GetStagesByAssignedLogin возвращает все этапы, назначенные на логин (без фильтра
// по дедлайну). Для сервисного API /api/tasks/by-user: navgit по Stage.ID (= JobId
// в Dev history 52290) находит объекты задачи разработчика.
func (s *LocalStore) GetStagesByAssignedLogin(login string) []*models.Stage {
	rows, db, err := s.query(`SELECT id,task_id,assigned_login,name,start_date,end_date,url_link,status,stage_type,created_at,updated_at FROM stages WHERE assigned_login=? AND status != 'Отмена' ORDER BY COALESCE(start_date,'9999') ASC`, login)
	if err != nil {
		return nil
	}
	defer db.Close()
	defer rows.Close()
	var out []*models.Stage
	for rows.Next() {
		out = append(out, scanStage(rows))
	}
	return out
}

// GetStagesUnassignedForManager returns unassigned stages for tasks in manager's department,
// PLUS tasks that have NO stages at all (those go as virtual placeholder rows)
func (s *LocalStore) GetStagesUnassignedForManager(user *models.User) ([]*models.Stage, []string) {
	department, err := s.GetUserDepartment(user)
	if err != nil {
		return nil, nil
	}

	// Unassigned stages (assigned_login='') in dept tasks
	rows, db, err := s.query(`
		SELECT st.id, st.task_id, st.assigned_login, st.name,
		       st.start_date, st.end_date, st.url_link, st.status,
		       st.stage_type, st.created_at, st.updated_at
		FROM stages st
		JOIN tasks t ON t.id = st.task_id
		WHERE st.assigned_login = ''
		  AND t.executor_dept_id = ?
		  AND status != 'Отмена'
		ORDER BY COALESCE(st.start_date,'9999') ASC`, department.ID)
	var stages []*models.Stage
	if err == nil {
		defer db.Close()
		defer rows.Close()
		for rows.Next() {
			stages = append(stages, scanStage(rows))
		}
	}

	// Tasks with zero stages in this dept
	rows2, db2, err2 := s.query(`
		SELECT t.id FROM tasks t
		LEFT JOIN stages st ON st.task_id = t.id
		WHERE t.executor_dept_id = ?
		  AND st.id IS NULL
		ORDER BY t.id`, department.ID)
	var noStageTasks []string
	if err2 == nil {
		defer db2.Close()
		defer rows2.Close()
		for rows2.Next() {
			var tid string
			rows2.Scan(&tid)
			noStageTasks = append(noStageTasks, tid)
		}
	}

	return stages, noStageTasks
}

func (s *LocalStore) CreateStage(st *models.Stage) error {
	now := time.Now()
	st.CreatedAt = now
	st.UpdatedAt = now
	var ss, se interface{}
	if st.Start != nil {
		ss = st.Start.Format(time.RFC3339)
	}
	if st.End != nil {
		se = st.End.Format(time.RFC3339)
	}
	_, err := s.exec(`INSERT INTO stages (id,task_id,assigned_login,name,start_date,end_date,url_link,status,stage_type,created_at,updated_at)
		VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
		st.ID, st.TaskID, st.AssignedLogin, st.Name, ss, se, st.URLLink, st.Status, st.StageType,
		now.Format(time.RFC3339), now.Format(time.RFC3339))
	return err
}

func (s *LocalStore) UpdateStage(st *models.Stage) error {
	now := time.Now()
	st.UpdatedAt = now
	var ss, se interface{}
	if st.Start != nil {
		ss = st.Start.Format(time.RFC3339)
	}
	if st.End != nil {
		se = st.End.Format(time.RFC3339)
	}
	_, err := s.exec(`UPDATE stages SET assigned_login=?,name=?,start_date=?,end_date=?,url_link=?,status=?,stage_type=?,updated_at=? WHERE id=?`,
		st.AssignedLogin, st.Name, ss, se, st.URLLink, st.Status, st.StageType, now.Format(time.RFC3339), st.ID)
	return err
}

func (s *LocalStore) SaveStage(st *models.Stage) error {
	now := time.Now()
	if st.CreatedAt.IsZero() {
		st.CreatedAt = now
	}
	if st.CreatedAt.IsZero() {
		st.UpdatedAt = now
	}
	var ss, se interface{}
	if st.Start != nil {
		ss = st.Start.Format(time.RFC3339)
	}
	if st.End != nil {
		se = st.End.Format(time.RFC3339)
	}
	_, err := s.exec(`REPLACE INTO stages (id, task_id, assigned_login, name, start_date, end_date, url_link, status, stage_type, created_at, updated_at)
		VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
		st.ID, st.TaskID, st.AssignedLogin, st.Name, ss, se, st.URLLink, st.Status, st.StageType, st.CreatedAt.Format(time.RFC3339), st.UpdatedAt.Format(time.RFC3339))
	return err
}

func (s *LocalStore) DeleteStage(id string) error {
	_, err := s.exec(`DELETE FROM stages WHERE id=?`, id)
	return err
}

func (s *LocalStore) TaskHasUnassignedStages(taskID string) bool {
	rows, db, err := s.query(`SELECT COUNT(*) FROM stages WHERE task_id=? AND assigned_login='' AND status != 'Отмена' `, taskID)
	if err != nil {
		return false
	}
	defer db.Close()
	defer rows.Close()
	if rows.Next() {
		var cnt int
		rows.Scan(&cnt)
		return cnt > 0
	}
	return false
}

// ---- Comments ----

func (s *LocalStore) GetComments(entityType, entityID string) []*models.Comment {
	rows, db, err := s.query(`SELECT id,entity_type,entity_id,author_login,author_name,text,created_at FROM comments WHERE entity_type=? AND entity_id=? ORDER BY created_at ASC`, entityType, entityID)
	if err != nil {
		return nil
	}
	defer db.Close()
	defer rows.Close()
	var out []*models.Comment
	for rows.Next() {
		c := &models.Comment{}
		rows.Scan(&c.ID, &c.EntityType, &c.EntityID, &c.AuthorLogin, &c.AuthorName, &c.Text, &c.CreatedAt)
		out = append(out, c)
	}
	return out
}

func (s *LocalStore) AddComment(c *models.Comment) error {
	c.CreatedAt = time.Now()
	_, err := s.exec(`INSERT INTO comments (id,entity_type,entity_id,author_login,author_name,text,created_at) VALUES (?,?,?,?,?,?,?)`,
		c.ID, c.EntityType, c.EntityID, c.AuthorLogin, c.AuthorName, c.Text, c.CreatedAt.Format(time.RFC3339))
	return err
}

func (s *LocalStore) DeleteComment(id string) error {
	_, err := s.exec(`DELETE FROM comments WHERE id=?`, id)
	return err
}

// ---- Sessions ----

func (s *LocalStore) SaveSession(session *models.UthorizedLogin) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.sessions[session.Token] = session
}

func (s *LocalStore) GetSession(token uuid.UUID) (string, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	now := time.Now()
	e, ok := s.sessions[token]
	if !ok || now.After(e.LifeFor) {
		delete(s.sessions, token)
		return "", false
	} else {
		e.LifeFor = now.Add(time.Hour)
		s.sessions[e.Token] = e
	}
	return e.Login, true
}

// ---- ID generator ----

func GenID(prefix string) string {
	h := uint64(14695981039346656037)
	for _, c := range []byte(fmt.Sprintf("%s%d", prefix, time.Now().UnixNano())) {
		h ^= uint64(c)
		h *= 1099511628211
	}
	return fmt.Sprintf("%s-%010x", prefix, h&0xFFFFFFFFFF)
}

// ---- Table Stamp ====

func (s *LocalStore) GetExtTableStamp(id string) (*models.ExtTableStamp, error) {
	rows, db, err := s.query(`SELECT * FROM ext_table_stamp WHERE id=?`, id)
	if err != nil {
		return nil, err
	}
	defer db.Close()
	defer rows.Close()
	ts := &models.ExtTableStamp{}
	if rows.Next() {
		var stampStr string
		rows.Scan(&ts.ID, &stampStr)
		ts.Stamp = *parseTime(&stampStr)
		return ts, nil
	} else {
		ts.ID = id
		ts.Stamp = time.Now().Add(-time.Hour * 24 * 48 * 2)
	}
	return ts, nil
}

func (s *LocalStore) SaveExtTableStamp(ts *models.ExtTableStamp) error {
	_, err := s.exec(
		`REPLACE INTO ext_table_stamp (id, stamp) VALUES (?,?)`,
		ts.ID,
		ts.Stamp.Format(time.RFC3339),
	)
	return err
}
