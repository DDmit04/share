package config

type ServiceConfig struct {
	Port            string `json:"port"`
	SecurityAddress string `json:"security_address"`
}

func GetServiceConfig(name string) (*ServiceConfig, error) {
	var dbc = new(ServiceConfig)
	err := getConfig(name, dbc)
	if err != nil {
		return nil, err
	}
	return dbc, nil
}
