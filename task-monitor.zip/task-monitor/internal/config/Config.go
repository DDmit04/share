package config

import (
	"log"
	"taskmon/internal/exts/Json"
)

func getConfig[T any](name string, c *T) error {
	if errR := Json.ReadStructFromJSONFile(name, c); errR != nil {
		if errS := Json.SaveStructToJSONFile(name, c); errS != nil {
			log.Fatalf("Ошибка создания конфиг файла  %s\n", errS.Error())
			return errS
		}
		return errR
	}
	return nil
}
