package auth

import (
	"encoding/json"
	"io"
	"net/http"
	"taskmon/internal/config"
	"taskmon/internal/db"
	"taskmon/internal/exts"
	"taskmon/internal/models"

	"github.com/google/uuid"
)

const CookieName = "taskmon_sess"

const (
	headerAuthorization = "Authorization"
	headerLogin         = "X-Login"
	headerPass          = "X-Pass"
)

type Auth struct {
	store      *db.LocalStore
	config     *config.ServiceConfig
	httpClient *http.Client
}

func New(_store *db.LocalStore, _config *config.ServiceConfig) *Auth {
	return &Auth{
		store:      _store,
		config:     _config,
		httpClient: http.DefaultClient,
	}
}

// ===================== AUTH =====================

func (a *Auth) Login(w http.ResponseWriter, r *http.Request) {
	var req models.UthorizedRequest

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		exts.WriteUnauthorized(w)
		return
	}

	authReq, err := http.NewRequest(http.MethodPost, a.config.SecurityAddress+`/login`, nil)
	if err != nil {
		exts.WriteUnauthorized(w)
		return
	}
	authReq.Header.Set(headerLogin, req.Login)
	authReq.Header.Set(headerPass, req.Password)

	res, err := a.httpClient.Do(authReq)
	if err != nil {
		exts.WriteUnauthorized(w)
		return
	}
	defer res.Body.Close()

	var session models.UthorizedLogin

	switch res.StatusCode {
	case http.StatusOK:
		{
			decoder := json.NewDecoder(io.LimitReader(res.Body, 1*1024*1024)) // 1 МБ
			err = decoder.Decode(&session)
			if err != nil {
				exts.WriteUnauthorized(w)
				return
			}
		}
	default:
		{
			exts.WriteUnauthorized(w)
			return
		}
	}
	res.Body.Close()

	a.store.SaveSession(&session)

	http.SetCookie(w, &http.Cookie{
		Name:     CookieName,
		Value:    session.Token.String(),
		Path:     "/",
		HttpOnly: true,
		Expires:  session.LifeFor,
	})
	exts.WriteOk(w)
}

func (a *Auth) Logout(w http.ResponseWriter, r *http.Request) {
	http.SetCookie(w, &http.Cookie{Name: CookieName, Value: "", Path: "/", MaxAge: -1})
	exts.WriteOk(w)
}

func (a *Auth) Me(w http.ResponseWriter, r *http.Request) {
	user, isAuth := a.GetCurrentUser(r)
	if !isAuth {
		exts.WriteUnauthorized(w)
		return
	}
	ds, err := a.store.GetUserDepartmentStructure(user)
	if err != nil {
		exts.WriteUnauthorized(w)
		return
	}
	b := []byte(`{"login": "` + user.Login + `", "full_name": "` + user.FullName + `","role": "` + string(ds.Role) + `", "department_id": "` + ds.DepartmentID + `"}`)
	exts.WriteResponse(w, b)
}

func (a *Auth) GetCurrentUser(r *http.Request) (*models.User, bool) {
	c, err := r.Cookie(CookieName)
	if err != nil {
		return nil, false
	}

	token, err := uuid.Parse(c.Value)
	if err != nil {
		return nil, false
	}

	login, ok := a.store.GetSession(token)
	if !ok {
		return nil, false
	}
	return a.store.GetUser(login)
}

func (a *Auth) RequireAuth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if _, ok := a.GetCurrentUser(r); !ok {
			exts.WriteUnauthorized(w)
			return
		}
		next(w, r)
	}
}

func (a *Auth) RequireManager(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		user, ok := a.GetCurrentUser(r)
		if !ok {
			exts.WriteUnauthorized(w)
			return
		}

		ds, err := a.store.GetUserDepartmentStructure(user)
		if err != nil {
			exts.WriteUnauthorized(w)
			return
		}

		if ds.Role != models.RoleManager {
			exts.WriteForbidden(w)
			return
		}
		next(w, r)
	}
}
