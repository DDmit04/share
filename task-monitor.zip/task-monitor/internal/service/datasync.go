package service

import (
	"fmt"
	"log"
	"sync"
	"taskmon/internal/db"
	"taskmon/internal/exts/WaitGroup"
	"taskmon/internal/models"
	"time"
)

type DataSync struct {
	loalStore *db.LocalStore
	extStore  *db.ExtStore
}

func NewDataSync(_loalStore *db.LocalStore, _extStore *db.ExtStore) *DataSync {
	return &DataSync{
		loalStore: _loalStore,
		extStore:  _extStore,
	}
}

func (ds *DataSync) StartServe() error {
	defer time.AfterFunc(time.Minute, func() {
		go ds.StartServe()
	})

	fmt.Println(`[DataSync]: Start Serve`)

	taskStamp, err := ds.loalStore.GetExtTableStamp("task")
	if err != nil {
		return err
	}
	defer ds.loalStore.SaveExtTableStamp(taskStamp)

	stageStamp, err := ds.loalStore.GetExtTableStamp("stage")
	if err != nil {
		return err
	}
	defer ds.loalStore.SaveExtTableStamp(stageStamp)

	exstStoreTaskCh := make(chan *models.Task)
	newTaskStageCh := make(chan *models.Stage)

	exstStoreStageCh := make(chan *models.Stage)

	wg := sync.WaitGroup{}

	WaitGroup.Go(
		&wg,
		func() {
			if ds.extStore.GetTasksFromDateToChan(exstStoreTaskCh, taskStamp.Stamp); err != nil {
				log.Print("[GetTasksFromDateToChan] error:", err)
			} else {
				log.Print("[GetTasksFromDateToChan] End Succesful;")
			}
		},
	)

	WaitGroup.Go(
		&wg,
		func() {
			if err := ds.extStore.GetStagesFromDateToChan(exstStoreStageCh, stageStamp.Stamp); err != nil {
				log.Print("[GetStagesFromDateToChan] error:", err)
			} else {
				log.Print("[GetStagesFromDateToChan] End Succesful;")
			}
		},
	)

	WaitGroup.Go(
		&wg,
		func() {
			if err := ds.MergeTasks(exstStoreTaskCh, newTaskStageCh, taskStamp); err != nil {
				log.Print("[MergeTasks] error:", err)
			} else {
				log.Print("[MergeTasks] End Succesful;")
			}
		},
	)

	WaitGroup.Go(
		&wg,
		func() {
			if err := ds.MergeStages(exstStoreStageCh, newTaskStageCh, stageStamp); err != nil {
				log.Print("[MergeStages] error:", err)
			} else {
				log.Print("[MergeStages] End Succesful;")
			}
		},
	)

	wg.Wait()
	fmt.Println(`[DataSync]: End Serve`)
	return nil
}

func (ds *DataSync) MergeTasks(extTaskCh <-chan *models.Task, newTaskStageCh chan<- *models.Stage, taskStamp *models.ExtTableStamp) error {
	defer close(newTaskStageCh)
	for {
		task, opened := <-extTaskCh
		if !opened {
			fmt.Println(`[DataSync]: extTaskCh Closed`)
			break
		}
		exists, err := ds.loalStore.ExistsTask(task.ID)
		if err != nil {
			return err
		}
		if !exists {
			stages, err := ds.extStore.GetStagesByTask(*task)
			if err != nil {
				return err
			}
			for _, stage := range stages {
				newTaskStageCh <- stage
			}
		}
		err = ds.loalStore.SaveTask(task)
		if err != nil {
			return err
		}
		fmt.Println(`[DataSync]: SaveTask [` + task.ID + `] [` + task.UpdatedAt.Format(time.DateTime+`.000`) + `]`)

		if taskStamp.Stamp.Before(task.UpdatedAt) {
			taskStamp.Stamp = task.UpdatedAt
		}
	}
	return nil
}

func (ds *DataSync) MergeStages(extStageCh <-chan *models.Stage, newTaskStageCh <-chan *models.Stage, stageStamp *models.ExtTableStamp) error {
	cextStageChOpen, newTaskChOpen := true, true

	for cextStageChOpen || newTaskChOpen {
		select {
		case stage, isOpen := <-extStageCh:
			{
				if !isOpen {
					cextStageChOpen = false
					extStageCh = nil
					fmt.Println(`[DataSync]: extStageCh Cloce`)
					continue
				}

				err := ds.loalStore.SaveStage(stage)
				if err != nil {
					return err
				}
				fmt.Println(`[DataSync]: SaveStage from extStageCh [` + stage.ID + `] [` + stage.UpdatedAt.Format(time.DateTime+`.000`) + `]`)

				if stageStamp.Stamp.Before(stage.UpdatedAt) {
					stageStamp.Stamp = stage.UpdatedAt
				}
			}
		case stage, isOpen := <-newTaskStageCh:
			{
				if !isOpen {
					newTaskChOpen = false
					newTaskStageCh = nil
					fmt.Println(`[DataSync]: newTaskStageCh Cloce`)
					continue
				}

				err := ds.loalStore.SaveStage(stage)
				if err != nil {
					return err
				}
				fmt.Println(`[DataSync]: SaveStage from newTaskStageCh [` + stage.ID + `] [` + stage.UpdatedAt.Format(time.DateTime+`.000`) + `]`)
			}
		}
	}

	return nil
}
