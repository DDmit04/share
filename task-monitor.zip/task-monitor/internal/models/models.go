package models

import (
	"time"

	"github.com/google/uuid"
)

type Role string

const (
	RoleManager  Role = "manager"
	RoleEmployee Role = "employee"
)

type TaskStatus string

const (
	TaskStatusEvaluation    TaskStatus = "Оценка"
	TaskStatusCostAccept    TaskStatus = "Экономисты"
	TaskStatusSetResposible TaskStatus = "Определение ответственного"
	TaskStatusInWork        TaskStatus = "В работе"
	TaskStatusDone          TaskStatus = "Готово"
)

type TaskStage string

const (
	StageObservation TaskStage = "Обследование"
	StageWritingTZ   TaskStage = "Написание ТЗ"
	StageAgreement   TaskStage = "Согласование с архитектором"
	StageDevelopment TaskStage = "Разработка"
	StageTesting     TaskStage = "Тестирование"
	StageTechDoc     TaskStage = "Написание тех. док."
	StageInProd      TaskStage = "Разливка"
)

type TaskStageStatus string

const (
	StagePlan      TaskStageStatus = "В Плане"
	StageInWork    TaskStageStatus = "В работе"
	StagesDone     TaskStageStatus = "Готово"
	StageCancelled TaskStageStatus = "Отмена"
)

type User struct {
	Login    string `json:"login"`
	FullName string `json:"full_name"`
}

type UthorizedRequest struct {
	Login    string `json:"login"`
	Password string `json:"password"`
}

type DepartmentStructure struct {
	Login        string `json:"login"`
	DepartmentID string `json:"department_id"`
	Role         Role   `json:"role"`
}

type UthorizedLogin struct {
	Login   string
	Token   uuid.UUID `json:"Authorization"`
	LifeFor time.Time
}

type Department struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	ParentID string `json:"parent_id"`
}

type Task struct {
	ID                string     `json:"id"`
	Name              string     `json:"name"`
	EconomicEffect    string     `json:"economic_effect"`
	Start             *time.Time `json:"start,omitempty"`
	End               *time.Time `json:"end,omitempty"`
	URLLink           string     `json:"url_link"`
	Stage             TaskStatus `json:"status"`
	InitiatorFullName string     `json:"initiator_full_name"`
	InitiatorDeptID   string     `json:"initiator_dept_id"`
	ExecutorDeptID    string     `json:"executor_dept_id"`
	AssignedLogin     string     `json:"assigned_login"`
	CreatedAt         time.Time  `json:"created_at"`
	UpdatedAt         time.Time  `json:"updated_at"`
}

type Stage struct {
	ID            string          `json:"id"`
	TaskID        string          `json:"task_id"`
	AssignedLogin string          `json:"assigned_login"`
	Name          string          `json:"name"`
	Start         *time.Time      `json:"start,omitempty"`
	End           *time.Time      `json:"end,omitempty"`
	URLLink       string          `json:"url_link"`
	Status        TaskStageStatus `json:"status"`
	StageType     TaskStage       `json:"stage_type"`
	CreatedAt     time.Time       `json:"created_at"`
	UpdatedAt     time.Time       `json:"updated_at"`
}

type Comment struct {
	ID          string    `json:"id"`
	EntityType  string    `json:"entity_type"` // "task" or "stage"
	EntityID    string    `json:"entity_id"`
	AuthorLogin string    `json:"author_login"`
	AuthorName  string    `json:"author_name"`
	Text        string    `json:"text"`
	CreatedAt   time.Time `json:"created_at"`
}

type Holiday struct {
	Date    string `json:"date"` // "2026-01-01"
	Name    string `json:"name"`
	Country string `json:"country"` // "RU"
}

type ExtTableStamp struct {
	ID    string    `json:"id"`
	Stamp time.Time `json:"stamp"`
}

func TaskStatusColor(status TaskStatus) string {
	switch status {
	case TaskStatusEvaluation:
		return "#EA580C"
	case TaskStatusCostAccept:
		return "#CA8A04"
	case TaskStatusSetResposible:
		return "#9333EA"
	case TaskStatusInWork:
		return "#16A34A"
	case TaskStatusDone:
		return "#65A30D"
	default:
		return "#64748B"
	}
}

func StageTypeColor(stageType TaskStage) string {
	switch stageType {
	case StageObservation:
		return "#2563EB"
	case StageWritingTZ:
		return "#65A30D"
	case StageAgreement:
		return "#6B7280"
	case StageDevelopment:
		return "#16A34A"
	case StageTesting:
		return "#CA8A04"
	case StageTechDoc:
		return "#0284C7"
	case StageInProd:
		return "#f76c1b"
	default:
		return "#64748B"
	}
}

func StageStatusColor(status TaskStageStatus) string {
	switch status {
	case StagePlan:
		return "#94A3B8"
	case StageInWork:
		return "#3B82F6"
	case StagesDone:
		return "#22C55E"
	case StageCancelled:
		return "#111827"
	default:
		return "#94A3B8"
	}
}

func AllTaskStatuses() []TaskStatus {
	return []TaskStatus{TaskStatusEvaluation, TaskStatusCostAccept, TaskStatusSetResposible, TaskStatusInWork, TaskStatusDone}
}
func AllStageTypes() []TaskStage {
	return []TaskStage{StageObservation, StageWritingTZ, StageAgreement, StageDevelopment, StageTesting, StageTechDoc}
}

func AllStageStatuses() []TaskStageStatus {
	return []TaskStageStatus{StagePlan, StageInWork, StagesDone, StageCancelled}
}

// DefaultStages returns the standard set of stage skeletons for a new task
func DefaultStages(taskID string) []Stage {
	types := AllStageTypes()
	stages := make([]Stage, len(types))
	for i, t := range types {
		stages[i] = Stage{
			TaskID:    taskID,
			Name:      string(t),
			StageType: t,
			Status:    StagePlan,
		}
	}
	return stages
}
