package exts

func GetOrDefult[T any, K comparable](Map map[K]T, kay K, defult T) T {
	if val, ok := Map[kay]; ok {
		return val
	}
	return defult
}
