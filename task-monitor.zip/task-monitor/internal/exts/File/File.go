package file

import (
	"fmt"
	"os"
)

func DeleteFileIfExists(filename string) error {
	// Проверка существования файла
	if _, err := os.Stat(filename); err == nil {
		// Файл существует, удаляем его
		err := os.Remove(filename)
		if err != nil {
			return fmt.Errorf("ошибка при удалении файла: %v", err)
		}
	} else if os.IsNotExist(err) {
		return nil
	} else {
		return fmt.Errorf("не удалось проверить существование файла: %v", err)
	}

	return nil
}
