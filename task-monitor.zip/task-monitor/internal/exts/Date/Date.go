package date

import (
	"errors"
	"strings"
	"time"
)

type Date struct {
	Time time.Time
}

func (d *Date) UnmarshalJSON(b []byte) error {
	// убираем кавычки
	s := string(b)
	s = s[1 : len(s)-1]

	var err error

	if strings.Contains(s, `.`) {
		d.Time, err = time.Parse("02.01.2006", s)
		if err != nil {
			return err
		}
	}

	if strings.Contains(s, `-`) {
		d.Time, err = time.Parse("2006-01-02", s)
		if err != nil {
			return err
		}
	}

	if d.Time.IsZero() {
		return errors.New(`Не могу распаристь дату [` + s + `]`)
	}

	return nil
}
