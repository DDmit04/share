package date

import (
	"encoding/json"
	"errors"
)

type Float struct {
	Float64 float64
}

func (f *Float) UnmarshalJSON(b []byte) error {
	if b[0] == 34 {
		err := json.Unmarshal(b[1:len(b)-1], &f.Float64)
		if err != nil {
			return errors.New("CustomFloat64: UnmarshalJSON: " + err.Error())
		}
	} else {
		err := json.Unmarshal(b, &f.Float64)
		if err != nil {
			return errors.New("CustomFloat64: UnmarshalJSON: " + err.Error())
		}
	}
	return nil
}
