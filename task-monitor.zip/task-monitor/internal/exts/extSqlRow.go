package exts

import (
	"database/sql"
	"reflect"
)

func ScanObject[T any](rows *sql.Rows, o *T) error {
	s := reflect.ValueOf(o).Elem()
	numCols := s.NumField()
	columns := make([]interface{}, numCols)
	for i := 0; i < numCols; i++ {
		field := s.Field(i)
		columns[i] = field.Addr().Interface()
	}

	return rows.Scan(columns...)
}
