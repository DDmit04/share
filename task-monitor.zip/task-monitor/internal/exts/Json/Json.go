package Json

import (
	"encoding/json"
	"log"
	"os"
	"path/filepath"
)

func ReadStructFromJSONFile[T any](fileName string, c *T) error {
	file, err := os.OpenFile(fileName, os.O_RDWR, 0666)
	if err != nil {
		//SaveStructToJSONFile(fileName, c)
		return err
	}
	defer file.Close()
	decoder := json.NewDecoder(file)
	return decoder.Decode(c)
}

func SaveStructToJSONFile[T any](fileName string, data T) error {
	file, err := os.Create(fileName)
	if err != nil {
		return err
	}
	defer file.Close()
	encoder := json.NewEncoder(file)
	//encoder.SetIndent("", "  ") // красивый формат (можно убрать)
	return encoder.Encode(data)
}

func ReadAllStructFromFolderJSONFiles[T any](folderName string) ([]T, error) {
	entries, err := os.ReadDir(folderName)
	if err != nil {
		log.Fatal(err)
	}

	list := []T{}

	for _, e := range entries {
		var newItem T
		errWLP := ReadStructFromJSONFile(filepath.Join(folderName, e.Name()), &newItem)
		if errWLP != nil {
			return nil, err
		}

		list = append(list, newItem)
	}

	return list, nil
}

func ReadAllStructFromFolderJSONFilesToChanel[T any](folderName string, c *chan T) error {
	entries, err := os.ReadDir(folderName)
	if err != nil {
		log.Fatal(err)
	}

	for _, e := range entries {
		var newItem T
		err = ReadStructFromJSONFile(filepath.Join(folderName, e.Name()), &newItem)
		if err != nil {
			return err
		}
		*c <- newItem
	}

	return nil
}
