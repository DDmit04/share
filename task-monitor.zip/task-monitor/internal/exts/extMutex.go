package exts

import "sync"

func SaveLock(m *sync.Mutex) {
	if m == nil {
		m = new(sync.Mutex)
	}
	m.Lock()
}

func SaveUnlock(m *sync.Mutex) {
	if m != nil {
		m.Unlock()
	}
}
