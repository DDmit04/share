package exts

import (
	"bytes"
	"io"
)

func ReadAll(r io.Reader) ([]byte, error) {
	data := []byte{}
	part := make([]byte, 256)
	read := 1
	var errR error

	read, errR = r.Read(part)
	for read > 0 {
		data = append(data, part[:read]...)
		read, errR = r.Read(part)
		if errR != nil && errR != io.EOF {
			return nil, errR
		}
	}

	return bytes.Trim(data, "\x00"), nil
}
