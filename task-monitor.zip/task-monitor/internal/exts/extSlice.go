package exts

import (
	"reflect"
)

func ListToSting(list []string) string {
	var result = ""
	for _, v := range list {
		result += v + " "
	}
	return result
}

func Find[T any](list []T, item T) int {
	for i := range list {
		if reflect.DeepEqual(item, (list)[i]) {
			return i
		}
	}
	return -1
}

func FindIndexComplex[T any](list []T, equal func(T) bool) int {
	for i := range list {
		if equal((list)[i]) {
			return i
		}
	}
	return -1
}

func FindComplex[T any](list []T, equal func(T) bool) *T {
	for i := range list {
		if equal(list[i]) {
			return &list[i]
		}
	}
	return nil
}

func Remove[T comparable](list []T, item T) []T {
	index := Find(list, item)
	if index == -1 {
		// вернуть копию, чтобы точно не трогать оригинал
		return append([]T(nil), list...)
	}

	result := make([]T, 0, len(list)-1)
	result = append(result, list[:index]...)
	result = append(result, list[index+1:]...)

	return result
}

func RemoveComplex[T any](list []T, equal func(T) bool) []T {
	index := FindIndexComplex(list, equal)
	if index == -1 {
		// вернуть копию, чтобы точно не трогать оригинал
		return append([]T(nil), list...)
	}

	result := make([]T, 0, len(list)-1)
	result = append(result, list[:index]...)
	result = append(result, list[index+1:]...)

	return result
}

func RemoveAllComplex[T any](list []T, equal func(T) bool) []T {
	newList := []T{}
	for i := range list {
		if !equal((list)[i]) {
			newList = append(newList, list[i])
		}
	}
	return newList
}

func DestinctBy[T any, R comparable](list []T, geter func(T) R) []R {
	set := map[R]interface{}{}
	for _, item := range list {
		set[geter(item)] = nil
	}
	newlist := []R{}
	for key := range set {
		newlist = append(newlist, key)
	}
	return newlist
}

func FindAllComplex[T any](list []T, equal func(T) bool) []T {
	var newList []T = list
	for i := range list {
		if equal((list)[i]) {
			newList = append(newList, list[i])
		}
	}
	return newList
}

func FindIndexComplexWI[T any](list []T, equal func(T) bool) int {
	for i := range list {
		if equal((list)[i]) {
			return i
		}
	}
	return -1
}

func Containts[T any](list []T, item T) bool {
	return Find(list, item) != -1
}

func ContaintsComplex[T any, R any](list []T, item R, equal func(T, R) bool) bool {
	for i := range list {
		if equal((list)[i], item) {
			return true
		}
	}
	return false
}
