'use strict';

const App = (() => {
  // ── State ──────────────────────────────────────────────────────────────
  let me = null, colors = null, calData = null;
  let taskFormId = null, stageFormTaskId = null, stageFormId = null, openTaskId = null;
  let searchQuery = '', filterStatus = '', filterStageType = '';
  let filterListenersSetup = false;

  const COL_PX = 28;

  // ── API ────────────────────────────────────────────────────────────────
  async function api(method, path, body) {
    const opts = { method, headers: {'Content-Type':'application/json'}, credentials: 'same-origin' };
    if (body !== undefined) opts.body = JSON.stringify(body);
    const res = await fetch(path, opts);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || res.statusText);
    return data;
  }

  function showPage(id) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById('page-' + id).classList.add('active');
  }

  // ── LOGIN ──────────────────────────────────────────────────────────────
  async function login() {
    const loginVal = document.getElementById('login-input').value.trim();
    const passVal  = document.getElementById('password-input').value;
    const errEl    = document.getElementById('login-error');
    errEl.style.display = 'none';
    try {
      await api('POST', '/api/login', { login: loginVal, password: passVal });
      await init();
    } catch(e) { errEl.textContent = e.message; errEl.style.display = 'block'; }
  }

  async function logout() {
    await api('POST', '/api/logout').catch(() => {});
    me = null; calData = null;
    showPage('login');
  }

  // ── INIT ───────────────────────────────────────────────────────────────
  async function init() {
    try {
      [me, colors] = await Promise.all([api('GET','/api/me'), api('GET','/api/ref/colors')]);
    } catch(e) { showPage('login'); return; }

    const roleEl = document.getElementById('nav-role');
    roleEl.textContent = me.role === 'manager' ? 'Руководитель' : 'Сотрудник';
    roleEl.className = 'role-badge ' + (me.role === 'manager' ? 'role-manager' : 'role-employee');
    document.getElementById('nav-name').textContent = me.full_name;
    document.getElementById('btn-new-task').style.display = me.role === 'manager' ? '' : 'none';

    // Populate filter dropdowns
    buildFilterUI();
    showPage('calendar');
    await loadCalendar();
  }

  function buildFilterUI() {
    const statusSel = document.getElementById('filter-status');
    const typeSel   = document.getElementById('filter-type');
    const si        = document.getElementById('cal-search');
    if (!statusSel || !typeSel || !si) return;
    statusSel.innerHTML = '<option value="">Все статусы</option>' +
      (colors.all_task_statuses||[]).map(s=>`<option value="${esc(s)}">${esc(s)}</option>`).join('');
    typeSel.innerHTML = '<option value="">Все типы</option>' +
      (colors.all_stage_types||[]).map(s=>`<option value="${esc(s)}">${esc(s)}</option>`).join('');
    if (!filterListenersSetup) {
      si.addEventListener('input', e => { searchQuery = e.target.value; if (calData) rerenderBody(calData); });
      statusSel.addEventListener('change', e => { filterStatus = e.target.value; if (calData) rerenderBody(calData); });
      typeSel.addEventListener('change', e => { filterStageType = e.target.value; if (calData) rerenderBody(calData); });
      filterListenersSetup = true;
    }
    document.getElementById('filter-bar').style.display = 'flex';
  }

  // ── CALENDAR ───────────────────────────────────────────────────────────
  async function loadCalendar() {
    calData = await api('GET', '/api/calendar');
    renderCalendar(calData);
    renderStats(calData.stats);
    requestAnimationFrame(() => requestAnimationFrame(scrollToToday));
  }

  function showCalendar() { loadCalendar(); }

  function applyFilters(employees) {
    if (!searchQuery && !filterStatus && !filterStageType) return employees;
    return employees.map(emp => {
      const tasks = (emp.tasks || []).filter(t => {
        if (filterStatus && t.status !== filterStatus) return false;
        if (filterStageType && !(t.stages||[]).some(s => s.stage_type === filterStageType)) return false;
        if (searchQuery) {
          const q = searchQuery.toLowerCase();
          if (!t.name.toLowerCase().includes(q)) return false;
        }
        return true;
      });
      return { ...emp, tasks };
    }).filter(emp => emp.tasks.length > 0 || emp.is_virtual);
  }

  function renderStats(stats) {
    const bar = document.getElementById('stats-bar');
    if (!stats || !stats.length) { bar.style.display = 'none'; return; }
    bar.style.display = 'flex';
    const c = document.getElementById('stats-items');
    c.innerHTML = '';
    stats.forEach(s => {
      const div = document.createElement('div');
      div.className = 'stat-item' + (s.login === '__unassigned__' ? ' stat-item-virtual' : '');
      div.innerHTML = `<span class="stat-name">${esc(s.full_name)}</span>` +
        s.months.map(m =>
          `<span class="stat-sep">·</span><span class="stat-month">${esc(m.month)}:</span>` +
          `<span class="stat-val stat-${m.class}">${Math.round(m.hours)}ч</span>`
        ).join('');
      c.appendChild(div);
    });
  }

  function renderCalendar(data) {
    const days = data.days;
    const thead = document.getElementById('cal-thead');
    const tbody = document.getElementById('cal-tbody');
    thead.innerHTML = ''; tbody.innerHTML = '';

    // Month/week groups
    const months=[], weeks=[];
    let curM='', curMSpan=0, curW=-1, curWSpan=0;
    const MN=['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
    days.forEach(d => {
      const dt = new Date(d.date);
      const mn = MN[dt.getMonth()] + ' ' + dt.getFullYear();
      const tmp = new Date(dt); tmp.setUTCDate(tmp.getUTCDate()+4-(tmp.getUTCDay()||7));
      const wn = Math.ceil(((tmp - new Date(tmp.getUTCFullYear(),0,1))/864e5+1)/7);
      if (mn !== curM) { if (curM) months.push({name:curM,span:curMSpan}); curM=mn; curMSpan=0; } curMSpan++;
      if (wn !== curW) { if (curW!==-1) weeks.push({num:curW,span:curWSpan}); curW=wn; curWSpan=0; } curWSpan++;
    });
    if (curM) months.push({name:curM,span:curMSpan});
    if (curW!==-1) weeks.push({num:curW,span:curWSpan});

    // Header rows
    const r1 = document.createElement('tr');
    const nc = document.createElement('th');
    nc.className='cal-name-col'; nc.rowSpan=3;
    r1.appendChild(nc);
    months.forEach(m => { const th=document.createElement('th'); th.className='cal-month'; th.colSpan=m.span; th.textContent=m.name; r1.appendChild(th); });
    thead.appendChild(r1);

    const r2 = document.createElement('tr');
    weeks.forEach(w => { const th=document.createElement('th'); th.className='cal-week'; th.colSpan=w.span; th.textContent='Нед.'+w.num; r2.appendChild(th); });
    thead.appendChild(r2);

    const r3 = document.createElement('tr');
    days.forEach(d => {
      const th = document.createElement('th');
      th.className = 'cal-day' + (d.is_today ? ' cal-today-col' : '');
      th.textContent = d.label;
      if (d.is_holiday) { addTooltip(th, d.holiday_name); th.style.color='#f87171'; }
      r3.appendChild(th);
    });
    thead.appendChild(r3);

    rerenderBody(data);
    requestAnimationFrame(drawTodayLine);
  }

  function rerenderBody(data) {
    const tbody = document.getElementById('cal-tbody');
    tbody.innerHTML = '';
    const filtered = applyFilters(data.employees || []);
    const n = data.days.length;

    filtered.forEach(emp => {
      const isVirtual = emp.is_virtual;

      // Employee header
      const empTr = document.createElement('tr');
      empTr.className = 'emp-header-row' + (isVirtual ? ' emp-virtual' : '');
      const empNameTd = document.createElement('td');
      empNameTd.className = 'emp-name-cell';
      const icon = isVirtual
        ? `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#f97316" stroke-width="2"><circle cx="12" cy="12" r="9"/><line x1="12" y1="8" x2="12" y2="16"/></svg>`
        : `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg>`;
      empNameTd.innerHTML = `<div class="emp-name${isVirtual?' emp-name-virtual':''}">${icon}${esc(emp.full_name)}</div>`;
      empTr.appendChild(empNameTd);

      const empCalTd = document.createElement('td');
      empCalTd.colSpan = n;
      empCalTd.className = 'emp-overload-cell';
      empCalTd.style.cssText = 'height:6px;padding:0;position:relative;';
      (emp.overload||[]).forEach(ol => {
        const bar = document.createElement('div');
        bar.className = 'overload-bar';
        bar.style.left  = (ol.start * COL_PX) + 'px';
        bar.style.width = ((ol.end - ol.start + 1) * COL_PX) + 'px';
        empCalTd.appendChild(bar);
      });
      empTr.appendChild(empCalTd);
      tbody.appendChild(empTr);

      // Task rows
      (emp.tasks||[]).forEach(task => {
        const tr = document.createElement('tr');
        tr.className = 'task-row';

        const nameTd = document.createElement('td');
        nameTd.className = 'task-name-cell';
        const link = document.createElement('div');
        link.className = 'task-link';
        link.onclick = () => openTask(task.task_id);

        // Unassigned stages flag
        let flag = '';
        if (task.has_unassigned_stages) {
          flag = `<span class="unassigned-flag" title="Есть нераспределённые этапы">⚑</span>`;
        }
        if (task.no_stages) {
          flag = `<span class="unassigned-flag no-stages-flag" title="Нет этапов">!</span>`;
        }

        const effect = task.economic_effect ? String(task.economic_effect).trim() : '';
        link.innerHTML = `<span class="task-dot" style="background:${task.color}"></span>` +
          `<span class="task-link-text">` +
            `<span class="task-link-name">${esc(task.name.substring(0, 50))}</span>` +
            (effect ? `<span class="task-link-effect">Экономический эффект: ${esc(effect)}</span>` : '') +
          `</span>${flag}`;
        addTooltip(link, [task.name, effect ? 'Экономический эффект: ' + effect : '', task.status,
          task.has_unassigned_stages ? 'Есть нераспределённые этапы' : '',
          task.no_stages ? 'Нет этапов' : ''
        ].filter(Boolean).join(' · '));
        nameTd.appendChild(link);
        tr.appendChild(nameTd);

        const calTd = document.createElement('td');
        calTd.className = 'task-cal-cell';
        const tl = document.createElement('div');
        tl.className = 'task-timeline';
        buildTaskBars(tl, task);
        calTd.appendChild(tl);
        tr.appendChild(calTd);
        tbody.appendChild(tr);
      });
    });
  }

  function openLink(linkUrl){
      if (linkUrl){
        let link = document.createElement("a");
        link.href = linkUrl;
        link.target = "_blank";
        document.body.appendChild(link);
        link.click(); 
        document.body.removeChild(link);
      }
  }

  function buildTaskBars(tl, task) {
    if (task.has_dates && task.stages && task.stages.length) {
      task.stages.forEach(st => {
        const bar = document.createElement('div');
        bar.className = 'stage-bar';
        bar.style.cssText = `left:${st.start_day*COL_PX}px;width:${(st.end_day-st.start_day+1)*COL_PX}px;background:${st.color};`;
        bar.innerHTML = `<span class="bar-label">${esc(st.stage_type)}</span>`;

        const tip = [st.name, st.stage_type, st.status, st.start_date&&st.end_date ? st.start_date+'–'+st.end_date : ''].filter(Boolean).join(' · ');
        addTooltip(bar, tip);
        bar.onclick = () => openLink(st.url_link);
        // Drag-and-drop
        makeDraggable(bar, st, task.task_id);
        tl.appendChild(bar);
      });
    } else if (task.has_dates) {
      const bar = document.createElement('div');
      bar.className = 'stage-bar';
      bar.style.cssText = `left:0;right:0;background:${task.color}80;`;
      bar.innerHTML = `<span class="bar-label">${esc(task.status)}</span>`;
      addTooltip(bar, task.name + ' · ' + task.status);
      bar.onclick = () => openLink(st.url_link);
      tl.appendChild(bar);
    } else {
      const bar = document.createElement('div');
      bar.className = 'task-bar-full';
      bar.style.cssText = `background:${task.color}20;border-color:${task.color}60;`;
      bar.innerHTML = `<span class="bar-label" style="color:${task.color}">${esc(task.name)}</span>`;
      addTooltip(bar, task.name + ' · Без дат · ' + task.status);
      bar.onclick = () => openLink(st.url_link);
      tl.appendChild(bar);
    }
  }

  // ── DRAG-AND-DROP (stage bars) ─────────────────────────────────────────
  function makeDraggable(bar, st, taskId) {
    if (!me || me.role !== 'manager') return;
    bar.draggable = true;
    bar.style.cursor = 'grab';

    let dragStartX = 0, origStartDay = st.start_day, origEndDay = st.end_day;
    const duration = st.end_day - st.start_day;

    bar.addEventListener('dragstart', e => {
      dragStartX = e.clientX;
      origStartDay = st.start_day;
      origEndDay = st.end_day;
      bar.style.opacity = '0.6';
      bar.style.cursor = 'grabbing';
      e.dataTransfer.setData('text/plain', st.stage_id);
    });

    bar.addEventListener('drag', e => {
      if (!e.clientX) return;
      const delta = Math.round((e.clientX - dragStartX) / COL_PX);
      const newStart = Math.max(0, origStartDay + delta);
      const newEnd   = newStart + duration;
      bar.style.left  = (newStart * COL_PX) + 'px';
      bar.style.width = ((newEnd - newStart + 1) * COL_PX) + 'px';
      bar.dataset.pendingStart = newStart;
      bar.dataset.pendingEnd   = newEnd;
    });

    bar.addEventListener('dragend', async e => {
      bar.style.opacity = '';
      bar.style.cursor = 'grab';
      const newStart = parseInt(bar.dataset.pendingStart ?? origStartDay);
      const newEnd   = parseInt(bar.dataset.pendingEnd   ?? origEndDay);
      if (newStart === origStartDay) return; // no change

      // Map day indices back to dates
      const days = calData?.days;
      if (!days || newStart >= days.length || newEnd >= days.length) { loadCalendar(); return; }
      const startDate = days[newStart].date;
      const endDate   = days[newEnd].date;

      try {
        await api('PUT', '/api/stages/' + st.stage_id, {
          task_id: st.task_id,
          name: st.name, stage_type: st.stage_type, status: st.status,
          assigned_login: st.assigned_login || '',
          start: startDate + 'T00:00:00Z',
          end:   endDate   + 'T00:00:00Z',
          url_link: st.url_link || '',
        });
        // Reload only body, not full calendar to avoid scroll reset
        await loadCalendar();
      } catch(err) {
        console.error('Drag save failed:', err);
        loadCalendar();
      }
    });
  }

  // ── TODAY ──────────────────────────────────────────────────────────────
  function scrollToToday() {
    const scroll = document.getElementById('cal-scroll');
    const todayTh = document.querySelector('#cal-thead .cal-today-col');
    if (!todayTh || !scroll) return;
    const targetLeft = todayTh.offsetLeft - scroll.clientWidth / 2 + todayTh.offsetWidth / 2;
    scroll.scrollTo({ left: Math.max(0, targetLeft), behavior: 'smooth' });
  }

  function drawTodayLine() {
    document.querySelectorAll('.today-line').forEach(el => el.remove());
    const todayTh = document.querySelector('#cal-thead .cal-today-col');
    const table = document.getElementById('cal-table');
    const scroll = document.getElementById('cal-scroll');
    if (!todayTh || !table || !scroll) return;
    const scrollRect = scroll.getBoundingClientRect();
    const thRect = todayTh.getBoundingClientRect();
    const left = thRect.left - scrollRect.left + scroll.scrollLeft + thRect.width / 2;
    const line = document.createElement('div');
    line.className = 'today-line';
    line.style.cssText = `left:${left}px;top:0;height:${table.offsetHeight}px;`;
    scroll.style.position = 'relative';
    scroll.appendChild(line);
  }

  window.addEventListener('resize', drawTodayLine);

  // ── TASK DETAIL ────────────────────────────────────────────────────────
  async function openTask(taskId) {
    openTaskId = taskId;
    document.getElementById('modal-task').style.display = 'flex';
    const body = document.getElementById('modal-task-body');
    body.className = 'modal-body';
    body.innerHTML = '<div style="display:flex;justify-content:center;padding:20px"><div class="spinner"></div></div>';
    document.getElementById('modal-task-footer').innerHTML = '';
    try {
      const data = await api('GET', '/api/tasks/' + taskId);
      renderTaskDetail(data);
    } catch(e) {
      body.innerHTML = `<div class="empty">Ошибка: ${esc(e.message)}</div>`;
    }
  }

  function renderTaskDetail(data) {
    const task = data.task, stages = data.stages||[], comments = data.comments||[];
    const color = data.task_color||'#64748b';
    const typeColors = data.stage_type_colors||{}, statusColors = data.stage_status_colors||{};
    const isManager = me && me.role === 'manager';
    const fd = s => s ? new Date(s).toLocaleDateString('ru-RU') : '<em class="text-muted">—</em>';
    const fdt = s => s ? new Date(s).toLocaleString('ru-RU') : '—';

    const body   = document.getElementById('modal-task-body');
    const footer = document.getElementById('modal-task-footer');
    body.className = 'modal-body modal-split';

    body.innerHTML = `
      <div class="modal-main">
        <div>
          <div class="detail-top-bar">
            <div class="detail-badges">
              <span class="status-badge" style="background:${color}">${esc(task.status)}</span>
              <span class="id-label">${esc(task.id)}</span>
              ${data.has_unassigned_stages ? `<span class="unassigned-badge">⚑ Есть нераспределённые этапы</span>` : ''}
            </div>
          </div>
          <div class="detail-title">${esc(task.name)}</div>
          <div class="detail-grid">
            <div class="detail-field"><label>Инициатор</label><span>${esc(task.initiator_full_name||'—')}</span></div>
            <div class="detail-field"><label>Подразделение</label><span>${esc(task.executor_dept_id||'—')}</span></div>
            ${task.economic_effect?`<div class="detail-field" style="grid-column:1/-1"><label>Экономический эффект</label><span>${esc(task.economic_effect)}</span></div>`:''}
            <div class="detail-field"><label>Начало</label><span>${fd(task.start)}</span></div>
            <div class="detail-field"><label>Окончание</label><span>${fd(task.end)}</span></div>
            ${task.url_link?`<div class="detail-field" style="grid-column:1/-1"><label>Ссылка</label><a href="${esc(task.url_link)}" target="_blank">${esc(task.url_link)}</a></div>`:''}
            <div class="detail-field"><label>Создана</label><span>${fdt(task.created_at)}</span></div>
            <div class="detail-field"><label>Обновлена</label><span>${fdt(task.updated_at)}</span></div>
          </div>
        </div>
        <hr class="divider">
        <div>
          <div class="stages-section-header">
            <h3>Этапы (${stages.length})</h3>
            ${isManager?`<button class="btn btn-primary btn-sm" onclick="App.openStageForm('${esc(task.id)}')">+ Этап</button>`:''}
          </div>
          ${stages.length===0?'<div class="empty" style="margin-top:10px">Этапы не добавлены</div>':''}
          <div style="display:flex;flex-direction:column;gap:10px;margin-top:10px">
            ${stages.map(st=>{
              const tc=typeColors[st.stage_type]||'#64748b', sc=statusColors[st.status]||'#94a3b8';
              return `<div class="stage-card" style="border-left:4px solid ${tc}">
                <div class="stage-card-head">
                  <span class="stage-type-badge" style="background:${tc}">${esc(st.stage_type)}</span>
                  <span class="stage-status-badge" style="background:${sc}"><span class="stage-status-dot"></span>${esc(st.status)}</span>
                  ${!st.assigned_login?`<span class="unassigned-stage-flag">⚑ Не распределён</span>`:''}
                </div>
                <div class="stage-name">${esc(st.name)}</div>
                <div class="detail-grid" style="margin-top:8px">
                  <div class="detail-field"><label>Ответственный</label><span>${esc(st.assigned_login||'—')}</span></div>
                  <div class="detail-field"><label>Начало</label><span>${fd(st.start)}</span></div>
                  <div class="detail-field"><label>Окончание</label><span>${fd(st.end)}</span></div>
                  ${st.url_link?`<div class="detail-field"><label>Ссылка</label><a href="${esc(st.url_link)}" target="_blank">↗</a></div>`:''}
                </div>
                ${isManager?`<div class="stage-actions">
                  <button class="btn btn-outline btn-xs" onclick="App.openStageForm('${esc(task.id)}','${esc(st.id)}')">✏️</button>
                  <button class="btn btn-danger btn-xs" onclick="App.deleteStage('${esc(st.id)}')">🗑️</button>
                </div>`:''}
              </div>`;
            }).join('')}
          </div>
        </div>
      </div>
      <div class="modal-sidebar">
        <div class="sidebar-header">Комментарии (${comments.length})</div>
        <div id="comments-list" class="sidebar-comments">
          ${comments.length === 0 ? '<div class="empty" style="padding:20px 0">Нет комментариев</div>' : ''}
          ${comments.map(c=>`
            <div class="comment-card">
              <div class="comment-header">
                <span class="comment-author">${esc(c.author_name)}</span>
                ${isManager?`<button class="btn-icon comment-del" onclick="App.deleteComment('${esc(c.id)}')">×</button>`:''}
              </div>
              <div class="comment-date" style="font-size:10px;color:var(--text3);margin-bottom:4px">${fdt(c.created_at)}</div>
              <div class="comment-text">${esc(c.text).replace(/\n/g,'<br>')}</div>
            </div>`).join('')}
        </div>
        <div class="sidebar-comment-form">
          <textarea id="comment-input" class="comment-textarea" placeholder="Написать комментарий..." rows="3"></textarea>
          <button class="btn btn-primary btn-sm" onclick="App.addComment('task','${esc(task.id)}')">Отправить</button>
        </div>
      </div>`;

    footer.innerHTML = isManager
      ? `<button class="btn btn-outline btn-sm" onclick="App.openTaskForm('${esc(task.id)}')">✏️ Редактировать</button>
         <button class="btn btn-danger btn-sm" onclick="App.deleteTask('${esc(task.id)}')">🗑️ Удалить</button>
         <button class="btn btn-ghost btn-sm" onclick="App.closeModal('task')">Закрыть</button>`
      : `<button class="btn btn-ghost btn-sm" onclick="App.closeModal('task')">Закрыть</button>`;
  }

  // ── COMMENTS ──────────────────────────────────────────────────────────
  async function addComment(entityType, entityId) {
    const input = document.getElementById('comment-input');
    const text = input.value.trim();
    if (!text) return;
    await api('POST', '/api/comments', { entity_type: entityType, entity_id: entityId, text });
    input.value = '';
    openTask(openTaskId);
  }

  async function deleteComment(id) {
    if (!confirm('Удалить комментарий?')) return;
    await api('DELETE', '/api/comments/' + id);
    openTask(openTaskId);
  }

  // ── TASK FORM ──────────────────────────────────────────────────────────
  async function openTaskForm(taskId) {
    taskFormId = taskId || null;
    document.getElementById('task-form-title').textContent = taskId ? 'Редактировать задачу' : 'Новая задача';
    document.getElementById('task-form-error').style.display = 'none';

    const [users, depts] = await Promise.all([api('GET','/api/ref/users'), api('GET','/api/ref/depts')]);

    document.getElementById('tf-status').innerHTML =
      (colors.all_task_statuses||[]).map(s=>`<option value="${esc(s)}">${esc(s)}</option>`).join('');
    document.getElementById('tf-assigned').innerHTML = '<option value="">— Не назначен —</option>' +
      (users||[]).map(u=>`<option value="${esc(u.login)}">${esc(u.full_name)}</option>`).join('');
    document.getElementById('tf-dept').innerHTML = '<option value="">— Не выбрано —</option>' +
      (depts||[]).map(d=>`<option value="${esc(d.id)}">${esc(d.name)}</option>`).join('');

    // Show/hide default stages checkbox only on create
    const defRow = document.getElementById('tf-default-stages-row');
    if (defRow) defRow.style.display = taskId ? 'none' : '';

    if (taskId) {
      const data = await api('GET', '/api/tasks/' + taskId);
      const t = data.task;
      document.getElementById('tf-name').value  = t.name||'';
      document.getElementById('tf-start').value = t.start ? t.start.substring(0,10) : '';
      document.getElementById('tf-end').value   = t.end   ? t.end.substring(0,10)   : '';
      document.getElementById('tf-url').value   = t.url_link||'';
      document.getElementById('tf-status').value   = t.status||'';
      document.getElementById('tf-assigned').value  = t.assigned_login||'';
      document.getElementById('tf-dept').value       = t.executor_dept_id||'';
    } else {
      ['tf-name','tf-start','tf-end','tf-url'].forEach(id => document.getElementById(id).value = '');
      document.getElementById('tf-status').value = colors.all_task_statuses?.[0]||'';
      const cb = document.getElementById('tf-default-stages');
      if (cb) cb.checked = true;
    }

    document.getElementById('modal-task').style.display = 'none';
    document.getElementById('modal-task-form').style.display = 'flex';
  }

  async function submitTaskForm() {
    const errEl = document.getElementById('task-form-error');
    errEl.style.display = 'none';
    const name = document.getElementById('tf-name').value.trim();
    if (!name) { errEl.textContent='Введите наименование'; errEl.style.display='block'; return; }

    const defCb = document.getElementById('tf-default-stages');
    const body = {
      name,
      start: document.getElementById('tf-start').value||null,
      end:   document.getElementById('tf-end').value||null,
      status: document.getElementById('tf-status').value,
      assigned_login: document.getElementById('tf-assigned').value||'',
      executor_dept_id: document.getElementById('tf-dept').value||'',
      url_link: document.getElementById('tf-url').value||'',
      create_default_stages: !taskFormId && defCb ? defCb.checked : false,
    };
    if (body.start) body.start = body.start+'T00:00:00Z';
    if (body.end)   body.end   = body.end  +'T00:00:00Z';

    try {
      if (taskFormId) { await api('PUT',  '/api/tasks/'+taskFormId, body); }
      else            { await api('POST', '/api/tasks', body); }
      closeModal('task-form');
      await loadCalendar();
    } catch(e) { errEl.textContent=e.message; errEl.style.display='block'; }
  }

  async function deleteTask(taskId) {
    if (!confirm('Удалить задачу?')) return;
    await api('DELETE', '/api/tasks/'+taskId);
    closeModal('task');
    await loadCalendar();
  }

  // ── STAGE FORM ─────────────────────────────────────────────────────────
  async function openStageForm(taskId, stageId) {
    stageFormTaskId = taskId; stageFormId = stageId||null;
    document.getElementById('stage-form-title').textContent = stageId ? 'Редактировать этап' : 'Новый этап';
    document.getElementById('stage-form-error').style.display = 'none';

    const users = await api('GET', '/api/ref/users');
    document.getElementById('sf-type').innerHTML =
      (colors.all_stage_types||[]).map(s=>`<option value="${esc(s)}">${esc(s)}</option>`).join('');
    document.getElementById('sf-status').innerHTML =
      (colors.all_stage_statuses||[]).map(s=>`<option value="${esc(s)}">${esc(s)}</option>`).join('');
    document.getElementById('sf-assigned').innerHTML = '<option value="">— Не распределено —</option>' +
      (users||[]).map(u=>`<option value="${esc(u.login)}">${esc(u.full_name)}</option>`).join('');

    if (stageId) {
      const data = await api('GET', '/api/tasks/'+taskId);
      const st = (data.stages||[]).find(s=>s.id===stageId);
      if (st) {
        document.getElementById('sf-name').value  = st.name||'';
        document.getElementById('sf-start').value = st.start ? st.start.substring(0,10) : '';
        document.getElementById('sf-end').value   = st.end   ? st.end.substring(0,10)   : '';
        document.getElementById('sf-url').value   = st.url_link||'';
        document.getElementById('sf-type').value     = st.stage_type||'';
        document.getElementById('sf-status').value   = st.status||'';
        document.getElementById('sf-assigned').value = st.assigned_login||'';
      }
    } else {
      ['sf-name','sf-start','sf-end','sf-url'].forEach(id => document.getElementById(id).value='');
    }

    document.getElementById('modal-task').style.display = 'none';
    document.getElementById('modal-stage-form').style.display = 'flex';
  }

  async function submitStageForm() {
    const errEl = document.getElementById('stage-form-error');
    errEl.style.display = 'none';
    const name = document.getElementById('sf-name').value.trim();
    if (!name) { errEl.textContent='Введите наименование'; errEl.style.display='block'; return; }

    const body = {
      task_id: stageFormTaskId, name,
      stage_type: document.getElementById('sf-type').value,
      status: document.getElementById('sf-status').value,
      assigned_login: document.getElementById('sf-assigned').value||'',
      start: document.getElementById('sf-start').value||null,
      end:   document.getElementById('sf-end').value||null,
      url_link: document.getElementById('sf-url').value||'',
    };
    if (body.start) body.start = body.start+'T00:00:00Z';
    if (body.end)   body.end   = body.end  +'T00:00:00Z';

    try {
      if (stageFormId) { await api('PUT',  '/api/stages/'+stageFormId, body); }
      else             { await api('POST', '/api/stages', body); }
      closeModal('stage-form');
      await loadCalendar();
      if (stageFormTaskId) openTask(stageFormTaskId);
    } catch(e) { errEl.textContent=e.message; errEl.style.display='block'; }
  }

  async function deleteStage(stageId) {
    if (!confirm('Удалить этап?')) return;
    await api('DELETE', '/api/stages/'+stageId);
    await loadCalendar();
    if (openTaskId) openTask(openTaskId);
  }

  // ── MODALS ─────────────────────────────────────────────────────────────
  function closeModal(name) {
    document.getElementById('modal-'+name).style.display = 'none';
    if ((name==='task-form'||name==='stage-form') && openTaskId) openTask(openTaskId);
    if (name==='task') openTaskId = null;
  }

  // ── TOOLTIP ────────────────────────────────────────────────────────────
  const tip = document.getElementById('tooltip');
  function addTooltip(el, text) {
    if (!text) return;
    el.addEventListener('mouseenter', e => {
      tip.innerHTML = text.split(' · ').map(s=>`<div>${esc(s)}</div>`).join('');
      tip.style.display = 'block'; moveTip(e);
    });
    el.addEventListener('mousemove', moveTip);
    el.addEventListener('mouseleave', () => { tip.style.display='none'; });
  }
  function moveTip(e) {
    const x=e.clientX+12, y=e.clientY-8;
    tip.style.left = (x+tip.offsetWidth>window.innerWidth ? x-tip.offsetWidth-20 : x)+'px';
    tip.style.top  = (y+tip.offsetHeight>window.innerHeight ? y-tip.offsetHeight : y)+'px';
  }

  // ── UTILS ──────────────────────────────────────────────────────────────
  function esc(s) {
    if (s==null) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

  // ── KEYBOARD ───────────────────────────────────────────────────────────
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      ['stage-form','task-form','task'].forEach(name => {
        const el = document.getElementById('modal-'+name);
        if (el && el.style.display!=='none') closeModal(name);
      });
    }
  });
  document.getElementById('password-input').addEventListener('keydown', e => { if(e.key==='Enter') login(); });
  document.getElementById('login-input').addEventListener('keydown', e => { if(e.key==='Enter') document.getElementById('password-input').focus(); });

  init();

  return {
    login, logout, showCalendar, scrollToToday,
    openTask, openTaskForm, submitTaskForm, deleteTask,
    openStageForm, submitStageForm, deleteStage,
    addComment, deleteComment, closeModal,
  };
})();
