package main

import (
	"embed"
	"flag"
	"fmt"
	"io/fs"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"taskmon/internal/auth"
	"taskmon/internal/config"
	"taskmon/internal/db"
	"taskmon/internal/handlers"
	"taskmon/internal/service"
)

//go:embed web/static
var embeddedStatic embed.FS

func main() {

	//TODO решить через env
	os.Setenv("HTTP_PROXY", "http://172.31.24.36:8090")
	os.Setenv("HTTPS_PROXY", "http://172.31.24.36:8090")
	os.Setenv("NO_PROXY", "robot-co")
	fmt.Println("HTTP_PROXY:", os.Getenv("HTTP_PROXY"))
	fmt.Println("HTTPS_PROXY:", os.Getenv("HTTPS_PROXY"))
	fmt.Println("NO_PROXY:", os.Getenv("NO_PROXY"))

	/*
		// log setup >>
		log.Println(`Init`)
		f, err := os.OpenFile("logs/log "+time.Now().Format("2006-01-02 15-04-05")+".txt", os.O_CREATE|os.O_RDWR|os.O_APPEND, 0666)
		if err != nil {
			log.Fatalf("error create log file: %v", err)
		}
		defer f.Close()
		log.SetOutput(f)
		// log setup <<
	*/

	configPath := flag.String("config", "ServiceConfig.json", "путь к файлу ServiceConfig.json")
	dbPath := flag.String("db", filepath.Join("data", "taskmon.db"), "путь к файлу базы SQLite")
	flag.Parse()

	configFile := resolveConfigPath(*configPath)

	serviceConfig, err := config.GetServiceConfig(configFile)
	if err != nil {
		log.Fatalf("error read ServiceConfig file: %v", err)
	}

	if serviceConfig.Port == `` {
		log.Fatalf("port in ServiceConfig is empy !")
	}

	if serviceConfig.SecurityAddress == `` {
		log.Fatalf("port in security_address is empy !")
	}

	localStore, err := db.NewLocalStore(*dbPath)
	if err != nil {
		log.Fatal("DB init error:", err)
	}

	extStore, err := db.NewExtStore()
	if err != nil {
		log.Fatal("DB init error:", err)
	}

	syncServise := service.NewDataSync(
		localStore,
		extStore,
	)

	go syncServise.StartServe()

	auth := auth.New(
		localStore,
		serviceConfig,
	)

	h := handlers.New(
		localStore,
		auth,
	)
	mux := http.NewServeMux()

	mux.HandleFunc("/api/login", auth.Login)
	mux.HandleFunc("/api/logout", auth.Logout)
	mux.HandleFunc("/api/me", auth.RequireAuth(auth.Me))
	mux.HandleFunc("/api/calendar", auth.RequireAuth(h.Calendar))
	mux.HandleFunc("/api/holidays", auth.RequireAuth(h.HolidaysGet))

	mux.HandleFunc("/api/tasks", auth.RequireAuth(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost {
			auth.RequireManager(h.TaskCreate)(w, r)
		} else {
			h.Tasks(w, r)
		}
	}))
	// Сервисный эндпоинт для внешнего сервиса navgit (задачи+этапы по логину).
	// Более длинный префикс, чем "/api/tasks/", поэтому ServeMux матчит его первым.
	mux.HandleFunc("/api/tasks/by-user/", auth.RequireManager(h.TasksByUser))

	mux.HandleFunc("/api/tasks/", auth.RequireAuth(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case http.MethodGet:
			h.TaskGet(w, r)
		case http.MethodPut:
			auth.RequireManager(h.TaskUpdate)(w, r)
		case http.MethodDelete:
			auth.RequireManager(h.TaskDelete)(w, r)
		}
	}))

	mux.HandleFunc("/api/stages", auth.RequireManager(h.StageCreate))
	mux.HandleFunc("/api/stages/", auth.RequireAuth(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case http.MethodPut:
			auth.RequireManager(h.StageUpdate)(w, r)
		case http.MethodDelete:
			auth.RequireManager(h.StageDelete)(w, r)
		}
	}))

	mux.HandleFunc("/api/comments", auth.RequireAuth(h.CommentAdd))
	mux.HandleFunc("/api/comments/", auth.RequireAuth(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodDelete {
			h.CommentDelete(w, r)
		}
	}))

	mux.HandleFunc("/api/ref/users", auth.RequireAuth(h.RefUsers))
	mux.HandleFunc("/api/ref/depts", auth.RequireAuth(h.RefDepts))
	mux.HandleFunc("/api/ref/colors", auth.RequireAuth(h.RefColors))

	staticRoot, err := fs.Sub(embeddedStatic, "web/static")
	if err != nil {
		log.Fatal("static embed error:", err)
	}
	fileServer := http.FileServerFS(staticRoot)
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if strings.Contains(r.URL.Path, ".") {
			fileServer.ServeHTTP(w, r)
			return
		}
		http.ServeFileFS(w, r, staticRoot, "index.html")
	})

	fmt.Printf("\n🚀 TaskMon запущен: http://localhost:%s\n   config: %s\n   db:     %s\n\n", serviceConfig.Port, configFile, *dbPath)
	log.Fatal(http.ListenAndServe(":"+serviceConfig.Port, mux))
}

// resolveConfigPath возвращает первый существующий конфиг из предсказуемых мест:
// явный путь (или путь в рабочем каталоге), каталог бинарника (запуск службой)
// и cmd/ (запуск из корня репозитория). Если ничего не найдено — исходный путь:
// config-пакет создаст файл по умолчанию.
func resolveConfigPath(name string) string {
	candidates := []string{name}
	if exe, err := os.Executable(); err == nil {
		candidates = append(candidates, filepath.Join(filepath.Dir(exe), name))
	}
	if !filepath.IsAbs(name) {
		candidates = append(candidates, filepath.Join("cmd", name))
	}
	for _, p := range candidates {
		if st, err := os.Stat(p); err == nil && !st.IsDir() {
			return p
		}
	}
	return name
}
